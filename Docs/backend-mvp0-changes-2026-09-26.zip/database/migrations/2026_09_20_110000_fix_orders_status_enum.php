<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * تعديل enum لـ orders.status ليتطابق مع OpenAPI
     * من: ['pending_payment', 'paid', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded']
     * إلى: ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded']
     *
     * ملاحظة: هذا المايجريشن للـ MySQL/MariaDB فقط.
     * في بيئة الاختبار (SQLite) يعمل تلقائياً بدون ALTER لأن SQLite لا يفرض enum.
     */
    public function up(): void
    {
        // SQLite لا يدعم CHANGE COLUMN — نتخطى في بيئة الاختبار
        if (DB::getDriverName() === 'sqlite') {
            return;
        }

        DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM('pending_payment','paid','pending','confirmed','processing','shipped','delivered','cancelled','refunded') NOT NULL DEFAULT 'pending'");
        DB::table('orders')->where('status', 'pending_payment')->update(['status' => 'pending']);
        DB::table('orders')->where('status', 'paid')->update(['status' => 'confirmed']);
        DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM(
            'pending',
            'confirmed',
            'processing',
            'shipped',
            'delivered',
            'cancelled',
            'refunded'
        ) NOT NULL DEFAULT 'pending'");
    }

    public function down(): void
    {
        if (DB::getDriverName() === 'sqlite') {
            return;
        }

        DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM(
            'pending_payment',
            'paid',
            'processing',
            'shipped',
            'delivered',
            'cancelled',
            'refunded'
        ) NOT NULL DEFAULT 'pending_payment'");
    }
};
