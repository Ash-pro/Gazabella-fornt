<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('order_sequences', function (Blueprint $table) {
            $table->unsignedInteger('year')->primary();
            $table->unsignedBigInteger('value');
        });
        Schema::table('orders', function (Blueprint $table) {
            $table->string('payment_method', 30)->default('jawwal_pay');
            $table->string('idempotency_key', 64)->nullable();
            $table->string('request_hash', 64)->nullable();
            $table->unique(['user_id', 'idempotency_key']);
        });
        Schema::table('payments', function (Blueprint $table) {
            $table->text('payment_url')->nullable();
            $table->timestamp('expires_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_sequences');
        Schema::table('orders', function (Blueprint $table) {
            $table->dropUnique(['user_id', 'idempotency_key']);
            $table->dropColumn(['payment_method', 'idempotency_key', 'request_hash']);
        });
        Schema::table('payments', fn (Blueprint $table) => $table->dropColumn(['payment_url', 'expires_at']));
    }
};
