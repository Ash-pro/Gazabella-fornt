<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // SQLite also enforces CHECK constraints for Laravel enums.
        Schema::table('orders', function (Blueprint $table) {
            $table->enum('status', ['pending_payment', 'paid', 'pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'])->default('pending')->change();
        });
        DB::table('orders')->where('status', 'pending_payment')->update(['status' => 'pending']);
        DB::table('orders')->where('status', 'paid')->update(['status' => 'confirmed']);
        Schema::table('orders', function (Blueprint $table) {
            $table->enum('status', ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'])->default('pending')->change();
        });
    }

    public function down(): void
    {
        // Status alignment is retained to avoid corrupting valid orders on rollback.
    }
};
