<?php

return [
    'paths' => ['api/*'],

    'allowed_methods' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],

    // القيمة الوحيدة المسموح بها من Frontend
    'allowed_origins' => [env('FRONTEND_URL', 'http://127.0.0.1:5173')],

    'allowed_origins_patterns' => [],

    'allowed_headers' => [
        'Content-Type',
        'Accept',
        'Authorization',
        'X-Guest-UUID',
        'Idempotency-Key',
        'Accept-Language',
        'X-Requested-With',
    ],

    'exposed_headers' => [],

    'max_age' => 86400,

    // false لأننا نستخدم Bearer token وليس cookies
    'supports_credentials' => false,
];
