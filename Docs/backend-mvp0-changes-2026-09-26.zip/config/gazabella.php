<?php

return [
    'active_cities' => ['خانيونس'],
    'otp' => [
        'ttl_seconds' => env('OTP_TTL_SECONDS', 300),
        'length' => 6,
        'test_mode' => env('OTP_TEST_MODE', false) && in_array(env('APP_ENV', 'production'), ['local', 'testing'], true),
        'test_code' => env('OTP_TEST_CODE', '123456'),
    ],
    'reservation' => [
        'ttl_minutes' => env('RESERVATION_TTL_MINUTES', 15),
        'max_extension_minutes' => 30,
    ],
    'order' => [
        'number_prefix' => 'GAZ',
    ],
    'guest_session' => [
        'ttl_hours' => 24,
    ],
];
