<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        api:      __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        channels: __DIR__.'/../routes/channels.php',
        apiPrefix: 'api',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // CORS فقط — نستخدم Sanctum Bearer Token فلا نحتاج EnsureFrontendRequestsAreStateful
        // إضافتها تُسبب 419 CSRF عند إرسال Origin header مع Bearer Token
        $middleware->api(prepend: [
            \Illuminate\Http\Middleware\HandleCors::class,
        ]);

        // لا نُعرّف alias لـ auth — Laravel يُسجّله تلقائياً كـ Authenticate::class
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->render(function (\DomainException $e, $request) {
            if ($request->is('api/*')) return response()->json(['message' => $e->getMessage()], 409);
        });
        $exceptions->render(function (\Illuminate\Auth\AuthenticationException $e, $request) {
            if ($request->expectsJson() || $request->is('api/*')) {
                return response()->json(['message' => 'غير مصرح بالوصول'], 401);
            }
        });

        $exceptions->render(function (\Illuminate\Validation\ValidationException $e, $request) {
            if ($request->expectsJson() || $request->is('api/*')) {
                return response()->json([
                    'message' => 'البيانات المدخلة غير صحيحة',
                    'errors'  => $e->errors(),
                ], 422);
            }
        });

        $exceptions->render(function (\Illuminate\Database\Eloquent\ModelNotFoundException $e, $request) {
            if ($request->expectsJson() || $request->is('api/*')) {
                return response()->json(['message' => 'المورد المطلوب غير موجود'], 404);
            }
        });
    })
    ->create();
