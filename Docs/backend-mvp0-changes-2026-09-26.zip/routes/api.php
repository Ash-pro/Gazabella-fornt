<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\ProductController;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Gazabella API Routes
|
|  API:    http://127.0.0.1:8000/api/v1
|  Reverb: ws://127.0.0.1:8080
|  Vite:   http://127.0.0.1:5173
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function () {

    // ── Health Check ──────────────────────────────────────────────────
    Route::get('health', function (): JsonResponse {
        return response()->json([
            'status'    => 'ok',
            'service'   => 'Gazabella API',
            'version'   => '1.0.0-mock',
            'timestamp' => now()->toIso8601String(),
            'endpoints' => [
                'api'     => 'http://127.0.0.1:8000/api/v1',
                'reverb'  => 'ws://127.0.0.1:8080',
                'openapi' => 'http://127.0.0.1:8000/openapi.yaml',
            ],
            'cors_allowed_origin' => config('cors.allowed_origins.0', 'http://127.0.0.1:5173'),
            'db'        => \DB::connection()->getPdo() ? 'connected' : 'disconnected',
        ]);
    });

    // ── OpenAPI Spec (JSON format) ────────────────────────────────────
    Route::get('openapi', function () {
        $yaml = public_path('openapi.yaml');
        if (!file_exists($yaml)) {
            return response()->json(['error' => 'openapi.yaml not found in public/'], 404);
        }
        // نُرجع YAML كنص مع Content-Type الصحيح
        return response(file_get_contents($yaml), 200)
            ->header('Content-Type', 'application/yaml')
            ->header('Access-Control-Allow-Origin', 'http://127.0.0.1:5173');
    });

    // ── Auth ──────────────────────────────────────────────────────────
    Route::prefix('auth')->group(function () {
        Route::post('guest/init',  [AuthController::class, 'guestInit']);
        Route::post('otp/send',    [AuthController::class, 'otpSend'])->middleware('throttle:6,1');
        Route::post('otp/verify',  [AuthController::class, 'otpVerify'])->middleware('throttle:10,1');
        Route::post('logout',      [AuthController::class, 'logout'])->middleware('auth:sanctum');
        Route::get('me', [AuthController::class, 'me'])->middleware('auth:sanctum');
    });

    // ── Products & Categories ─────────────────────────────────────────
    Route::get('categories',       [ProductController::class, 'categories']);
    Route::get('delivery-options', fn () => response()->json([
        'data' => \App\Models\DeliveryOption::active()->get(['id', 'name', 'description', 'fee', 'estimated_days']),
        'active_cities' => config('gazabella.active_cities'),
    ]));
    Route::get('products',         [ProductController::class, 'index']);
    Route::get('products/{slug}',  [ProductController::class, 'show']);

    // ── Cart ──────────────────────────────────────────────────────────
    Route::prefix('cart')->group(function () {
        Route::get('/',           [CartController::class, 'index']);
        Route::post('/',          [CartController::class, 'store']);
        Route::patch('{itemId}',  [CartController::class, 'update']);
        Route::delete('{itemId}', [CartController::class, 'destroy']);
        Route::post('reserve',    [CartController::class, 'reserve']);
        Route::post('heartbeat',  [CartController::class, 'heartbeat']); // READ-ONLY
    });

    // ── Orders ────────────────────────────────────────────────────────
    Route::prefix('orders')->middleware('auth:sanctum')->group(function () {
        Route::post('checkout/begin', [OrderController::class, 'checkoutBegin']);
        Route::post('checkout/quote', [OrderController::class, 'quote']);
        Route::post('/',              [OrderController::class, 'store']);
        Route::get('/',               [OrderController::class, 'index']);
        Route::get('{orderNumber}',   [OrderController::class, 'show']);
    });

    // ── Payments ──────────────────────────────────────────────────────
    Route::prefix('payments')->group(function () {
        Route::post('init',    [PaymentController::class, 'init'])->middleware('auth:sanctum');
        Route::post('webhook', [PaymentController::class, 'webhook']); // Jawwal Pay only
    });

});
