<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\GuestSession;
use App\Models\User;
use App\Services\CartService;
use App\Services\OtpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function me(Request $request): JsonResponse
    {
        $user = $request->user();
        return response()->json(['data' => [
            'id' => $user->id, 'name' => $user->name, 'phone' => $user->phone,
            'role' => 'customer', 'created_at' => $user->created_at->toIso8601String(),
        ]]);
    }
    public function __construct(
        private readonly OtpService  $otpService,
        private readonly CartService $cartService,
    ) {}

    // ── POST /auth/guest/init ─────────────────────────────
    public function guestInit(Request $request): JsonResponse
    {
        $request->validate(['guest_uuid' => 'required|uuid']);

        $guest = GuestSession::firstOrCreate(
            ['uuid' => $request->guest_uuid],
            ['expires_at' => now()->addHours(24)]
        );

        // جدّد الصلاحية إذا كانت على وشك الانتهاء (< 2 ساعة)
        if ($guest->expires_at->isPast() || now()->diffInHours($guest->expires_at, false) < 2) {
            $guest->update(['expires_at' => now()->addHours(24)]);
        }

        $status = $guest->wasRecentlyCreated ? 201 : 200;

        return response()->json([
            'guest_uuid' => $guest->uuid,
            'expires_at' => $guest->expires_at->toIso8601String(),
        ], $status);
    }

    // ── POST /auth/otp/send ───────────────────────────────
    public function otpSend(Request $request): JsonResponse
    {
        $request->validate([
            'phone' => ['required', 'regex:/^\+970[0-9]{9}$/'],
        ]);

        $phone = $request->phone;

        // Rate limit: إذا كان OTP موجوداً وTTL > 250 ثانية → رفض
        $remaining = $this->otpService->ttlRemaining($phone);
        if ($remaining > 250) {
            $retryAfter = $remaining - 250;
            return response()->json([
                'message'      => "انتظر {$retryAfter} ثانية قبل إعادة الإرسال",
                'retry_after'  => $retryAfter,
            ], 429);
        }

        $this->otpService->send($phone);

        $response = [
            'message'            => 'تم إرسال رمز التحقق',
            'expires_in_seconds' => 300,
        ];

        // في بيئة التطوير — أظهر الرمز مباشرة
        if (config('gazabella.otp.test_mode')) {
            $response['_dev_otp'] = config('gazabella.otp.test_code');
        }

        return response()->json($response);
    }

    // ── POST /auth/otp/verify ─────────────────────────────
    public function otpVerify(Request $request): JsonResponse
    {
        $request->validate([
            'phone' => ['required', 'regex:/^\+970[0-9]{9}$/'],
            'otp'   => ['required', 'digits:6'],
            'name'  => ['sometimes', 'nullable', 'string', 'max:100'],
        ]);

        $phone = $request->phone;
        $otp   = $request->otp;

        // في test_mode: قبول الرمز الثابت
        $valid = $this->otpService->verify($phone, $otp);

        if (!$valid) {
            return response()->json([
                'message' => 'رمز التحقق غير صحيح أو انتهت صلاحيته',
            ], 401);
        }

        return DB::transaction(function () use ($request, $phone) {
            // إيجاد أو إنشاء المستخدم
            $user = User::firstOrCreate(
                ['phone' => $phone],
                ['name'  => $request->input('name')]
            );

            // حذف tokens القديمة وإنشاء token جديد
            $user->tokens()->delete();
            $token = $user->createToken('gazabella-app')->plainTextToken;

            // دمج سلة الزائر مع حساب المستخدم
            $cartMerged = false;
            $guestUuid  = $request->header('X-Guest-UUID');

            if ($guestUuid) {
                $guest = GuestSession::where('uuid', $guestUuid)
                    ->where('expires_at', '>', now())
                    ->first();

                if ($guest) {
                    $user->newQuery()->whereKey($user->id)->lockForUpdate()->firstOrFail();
                    $guest->newQuery()->whereKey($guest->id)->lockForUpdate()->firstOrFail();
                    $items = \App\Models\CartItem::where('guest_session_id', $guest->id)->orderBy('id')->lockForUpdate()->get();
                    foreach ($items as $item) {
                        if ($item->reservation) app(\App\Services\ReservationService::class)->release($item->reservation);
                        $this->cartService->addItem($user, $item->product_variant_id, $item->quantity);
                        $item->delete();
                    }
                    $cartMerged = $items->isNotEmpty();
                    $guest->update(['expires_at' => now()]);

                }
            }

            Log::info("User verified: {$phone}");

            return response()->json([
                'token'       => $token,
                'token_type'  => 'Bearer',
                'user'        => [
                    'id'         => $user->id,
                    'name'       => $user->name,
                    'phone'      => $user->phone,
                    'role'       => 'customer',
                    'created_at' => $user->created_at->toIso8601String(),
                ],
                'cart_merged' => $cartMerged,
            ]);
        });
    }

    // ── POST /auth/logout ─────────────────────────────────
    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'تم تسجيل الخروج بنجاح']);
    }
}
