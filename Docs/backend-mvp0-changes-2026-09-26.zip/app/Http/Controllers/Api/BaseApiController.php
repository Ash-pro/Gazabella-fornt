<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\GuestSession;
use App\Models\User;
use Illuminate\Http\Request;

abstract class BaseApiController extends Controller
{
    /**
     * يحل المالك من الـ request:
     *  - Bearer token → User مسجّل
     *  - X-Guest-UUID  → GuestSession
     */
    protected function resolveOwner(Request $request): User|GuestSession
    {
        if ($request->bearerToken() && $user = $request->user('sanctum')) {
            return $user;
        }

        $uuid = $request->header('X-Guest-UUID');
        if (!$uuid) {
            abort(401, 'مطلوب تسجيل الدخول أو X-Guest-UUID');
        }

        $guest = GuestSession::where('uuid', $uuid)
            ->where('expires_at', '>', now())
            ->first();

        if (!$guest) {
            abort(401, 'جلسة الزائر منتهية أو غير موجودة — أعد إرسال /auth/guest/init');
        }

        return $guest;
    }

    /**
     * Format موحّد للـ Cart في كل responses
     */
    protected function formatCart(array $cart): array
    {
        $items = collect($cart['items'] ?? [])->map(fn($item) => [
            'id'                 => $item['cart_item_id'] ?? $item['id'],
            'product_variant_id' => $item['variant_id']   ?? $item['product_variant_id'],
            'product_name'       => $item['product_name'],
            'product_id'         => $item['product_id'],
            'product_slug'       => $item['product_slug'],
            'stock'              => $item['stock'],
            'variant_name'       => $item['variant_name'],
            'unit_price'         => number_format((float)($item['unit_price'] ?? 0), 2, '.', ''),
            'quantity'           => (int)$item['quantity'],
            'subtotal'           => number_format((float)($item['subtotal'] ?? 0), 2, '.', ''),
            'thumbnail_url'      => $item['image_url'] ?? $item['thumbnail_url'] ?? null,
            'reservation'        => $item['reservation'] ?? null,
        ])->values()->all();

        $subtotal = collect($items)->sum(fn($i) => (float)$i['subtotal']);

        return [
            'items'                  => $items,
            'total_items'            => collect($items)->sum('quantity'),
            'subtotal'               => number_format($subtotal, 2, '.', ''),
            'has_active_reservation' => collect($items)->contains(
                fn($i) => !empty($i['reservation'])
            ),
        ];
    }
}
