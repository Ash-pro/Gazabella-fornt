<?php

namespace App\Http\Controllers\Api;

use App\Models\Order;
use App\Services\OrderService;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PaymentController extends BaseApiController
{
    public function __construct(
        private readonly PaymentService $paymentService,
        private readonly OrderService   $orderService,
    ) {}

    /**
     * POST /api/v1/payments/init
     * بدء الدفع — يعيد payment_url لإرسال المستخدم إليه
     * مصادقة مطلوبة (auth:sanctum)
     */
    public function init(Request $request): JsonResponse
    {
        $data = $request->validate([
            'order_id' => 'required|integer|exists:orders,id',
        ]);

        $user  = $request->user();
        $order = Order::where('id', $data['order_id'])
            ->where('user_id', $user->id)
            ->firstOrFail();

        if ($order->status !== 'pending') {
            return response()->json([
                'message' => 'هذا الطلب ليس في حالة انتظار الدفع',
                'status'  => $order->status,
                'code'    => 'ORDER_NOT_PAYABLE',
            ], 422);
        }

        try {
            $result = $this->paymentService->initiate($order);
        } catch (\Exception $e) {
            Log::error("Payment init failed for order {$order->order_number}: " . $e->getMessage());

            return response()->json([
                'message' => 'فشل في تهيئة الدفع — حاول مجدداً',
                'code'    => 'PAYMENT_INIT_FAILED',
            ], 500);
        }

        return response()->json([
            'payment_id'  => $result['payment_id'],
            'payment_url' => $result['payment_url'],
            'expires_at'  => $result['expires_at'],
            'sandbox' => $result['sandbox'],
        ]);
    }

    /**
     * POST /api/v1/payments/webhook
     * Webhook من Jawwal Pay — لا يتطلب مصادقة
     * يجب التحقق من signature الـ HMAC
     */
    public function webhook(Request $request): JsonResponse
    {
        // التحقق من الـ signature
        if (!$this->verifyWebhookSignature($request)) {
            Log::warning('Webhook signature mismatch', ['ip' => $request->ip()]);
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $payload = $request->all();
        Log::info('Jawwal Pay Webhook received', ['order_ref' => $payload['merchant_ref'] ?? 'unknown']);

        try {
            $this->paymentService->handleWebhook($payload);
        } catch (\Illuminate\Validation\ValidationException $e) {
            throw $e;
        } catch (\DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 409);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Webhook: Order not found', ['ref' => $payload['merchant_ref'] ?? null]);
            // إعادة 200 لمنع Jawwal Pay من إعادة المحاولة بشكل متكرر
            return response()->json(['received' => true]);
        } catch (\Exception $e) {
            Log::error('Webhook processing error: ' . $e->getMessage());
            return response()->json(['message' => 'Processing error'], 500);
        }

        return response()->json(['received' => true]);
    }

    // ─────────────────────────────────────────────────
    // HMAC signature verification
    // ─────────────────────────────────────────────────

    private function verifyWebhookSignature(Request $request): bool
    {
        $secret = config('services.jawwal_pay.webhook_secret');

        // في وضع Sandbox — تخطي التحقق
        if (config('services.jawwal_pay.sandbox') && app()->environment(['local', 'testing'])) {
            return true;
        }
        if (empty($secret)) return false;

        $receivedSig = $request->header('X-Jawwal-Signature');
        if (!$receivedSig) return false;

        $expectedSig = hash_hmac('sha256', $request->getContent(), $secret);

        return hash_equals($expectedSig, $receivedSig);
    }
}
