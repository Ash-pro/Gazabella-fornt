<?php

namespace App\Http\Controllers\Api;

use App\Models\CartItem;
use App\Services\CartService;
use App\Services\ReservationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class CartController extends BaseApiController
{
    public function __construct(
        private readonly CartService        $cartService,
        private readonly ReservationService $reservationService,
    ) {}

    /**
     * GET /api/v1/cart
     * عرض السلة
     */
    public function index(Request $request): JsonResponse
    {
        $owner = $this->resolveOwner($request);
        $cart  = $this->cartService->getCart($owner);

        return response()->json([
            'data' => $this->formatCart($cart),
        ]);
    }

    /**
     * POST /api/v1/cart
     * إضافة منتج
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'product_variant_id' => 'required|integer|exists:product_variants,id',
            'quantity'           => 'required|integer|min:1|max:10',
        ]);

        $owner = $this->resolveOwner($request);

        try {
            $this->cartService->addItem($owner, $data['product_variant_id'], $data['quantity']);
        } catch (\DomainException $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'code'    => 'OUT_OF_STOCK',
            ], 409);
        }

        $cart = $this->cartService->getCart($owner);

        return response()->json([
            'message' => 'تمت إضافة المنتج للسلة',
            'data'    => $this->formatCart($cart),
        ], 200);
    }

    /**
     * PATCH /api/v1/cart/{itemId}
     * تعديل الكمية
     */
    public function update(Request $request, int $itemId): JsonResponse
    {
        $data  = $request->validate([
            'quantity' => 'required|integer|min:1|max:10',
        ]);

        $owner = $this->resolveOwner($request);
        $item  = $this->resolveCartItem($itemId, $owner);

        try {
            $this->cartService->updateItem($item, $data['quantity']);
        } catch (\DomainException $e) {
            return response()->json([
                'message'            => $e->getMessage(),
                'code'               => 'OUT_OF_STOCK',
            ], 409);
        }

        $cart = $this->cartService->getCart($owner);

        return response()->json([
            'message' => 'تم تحديث الكمية',
            'data'    => $this->formatCart($cart),
        ]);
    }

    /**
     * DELETE /api/v1/cart/{itemId}
     * حذف عنصر
     */
    public function destroy(Request $request, int $itemId): JsonResponse
    {
        $owner = $this->resolveOwner($request);
        $item  = $this->resolveCartItem($itemId, $owner);

        $this->cartService->removeItem($item);

        $cart = $this->cartService->getCart($owner);

        return response()->json([
            'message' => 'تم حذف المنتج من السلة',
            'data'    => $this->formatCart($cart),
        ]);
    }

    /**
     * POST /api/v1/cart/reserve
     * حجز جميع العناصر
     */
    public function reserve(Request $request): JsonResponse
    {
        $owner = $this->resolveOwner($request);
        $cart  = $this->cartService->getCart($owner);

        if (count($cart['items']) === 0) {
            return response()->json([
                'message' => 'السلة فارغة',
                'code'    => 'CART_EMPTY',
            ], 422);
        }

        [$ownerKey, $ownerId] = $this->ownerKey($request);
        $items = CartItem::where($ownerKey, $ownerId)->with(['reservation', 'variant.product'])->get();

        $errors = [];
        foreach ($items as $item) {
            // تخطي العناصر المحجوزة بالفعل (غير منتهية الصلاحية)
            if ($item->reservation && !$item->reservation->isExpired()) {
                continue;
            }

            try {
                $this->reservationService->reserve($item);
            } catch (\DomainException $e) {
                $errors[] = [
                    'cart_item_id' => $item->id,
                    'product_name' => $item->variant->product->name ?? '',
                    'variant_name' => $item->variant->name ?? '',
                    'requested'    => $item->quantity,
                    'available'    => $item->variant->available_quantity ?? 0,
                ];
            }
        }

        if (!empty($errors)) {
            return response()->json([
                'message'           => 'بعض العناصر غير متوفرة',
                'unavailable_items' => $errors,
            ], 409);
        }

        $freshCart   = $this->cartService->getCart($this->resolveOwner($request));
        $freshItems  = CartItem::where($ownerKey, $ownerId)->with('reservation')->get();
        $reservation = $freshItems->first()?->reservation;

        $reservedUntil     = $reservation?->expires_at?->toIso8601String();
        $secondsRemaining  = $reservation?->secondsRemaining() ?? 0;

        return response()->json([
            'message'           => 'تم حجز المنتجات بنجاح',
            'data'              => $this->formatCart($freshCart),
            'expires_at'        => $reservedUntil,
            'seconds_remaining' => $secondsRemaining,
        ]);
    }

    /**
     * POST /api/v1/cart/heartbeat
     * READ-ONLY — يُعيد الوقت المتبقي فقط، لا يُمدد الحجز
     */
    public function heartbeat(Request $request): JsonResponse
    {
        [$ownerKey, $ownerId] = $this->ownerKey($request);
        $items = CartItem::where($ownerKey, $ownerId)->with('reservation')->get();

        // إيجاد أول حجز نشط (non-expired)
        $activeReservation = null;
        foreach ($items as $item) {
            if ($item->reservation && !$item->reservation->isExpired()) {
                $activeReservation = $item->reservation;
                break;
            }
        }

        if ($activeReservation) {
            return response()->json([
                'has_reservation'   => true,
                'seconds_remaining' => $activeReservation->secondsRemaining(),
                'is_extended'       => (bool) ($activeReservation->extended_at !== null),
                'expires_at'        => $activeReservation->expires_at->toIso8601String(),
            ]);
        }

        return response()->json([
            'has_reservation'   => false,
            'seconds_remaining' => null,
            'is_extended'       => false,
            'expires_at'        => null,
        ]);
    }

    // ─────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────

    private function resolveCartItem(int $itemId, $owner): CartItem
    {
        [$key, $id] = $this->ownerKeyFromOwner($owner);

        $item = CartItem::with('variant')->where($key, $id)->find($itemId);

        if (!$item) {
            abort(404, 'عنصر السلة غير موجود');
        }

        return $item;
    }

    private function ownerKey(Request $request): array
    {
        $owner = $this->resolveOwner($request);
        return $this->ownerKeyFromOwner($owner);
    }

    private function ownerKeyFromOwner($owner): array
    {
        return $owner instanceof \App\Models\User
            ? ['user_id', $owner->id]
            : ['guest_session_id', $owner->id];
    }
}
