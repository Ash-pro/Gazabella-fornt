<?php

namespace App\Http\Controllers\Api;

use App\Models\Coupon;
use App\Models\DeliveryOption;
use App\Models\Order;
use App\Models\User;
use App\Services\OrderService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class OrderController extends BaseApiController
{
    public function __construct(
        private readonly OrderService  $orderService,
        private readonly \App\Services\CartService $cartService,
    ) {}

    /**
     * POST /api/v1/orders/checkout/begin
     * تمديد الحجوزات مرة واحدة وإعادة ملخص الطلب
     */
    public function checkoutBegin(Request $request): JsonResponse
    {
        $owner = $this->resolveOwner($request);

        // كوبون اختياري
        $coupon     = null;
        $couponData = null;
        $couponCode = $request->input('coupon_code');

        if ($couponCode) {
            $coupon = \App\Models\Coupon::where('code', strtoupper($couponCode))->first();
            if (!$coupon) {
                return response()->json([
                    'message' => 'رمز الكوبون غير صالح أو انتهت صلاحيته',
                    'code'    => 'INVALID_COUPON',
                ], 422);
            }
        }

        try {
            $summary = $this->orderService->beginCheckout($owner);
        } catch (\DomainException $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'code'    => 'CHECKOUT_FAILED',
            ], 409);
        }

        // خيارات التوصيل
        $deliveryOptions = DeliveryOption::active()->get()->map(fn($opt) => [
            'id'             => $opt->id,
            'name'           => $opt->name,
            'description'    => $opt->description ?? null,
            'fee'            => number_format((float) $opt->fee, 2, '.', ''),
            'estimated_days' => $opt->estimated_days,
            'is_available'   => (bool) ($opt->is_active ?? true),
        ]);

        // بيانات الكوبون للـ response
        if ($coupon && isset($summary['subtotal'])) {
            if (!$coupon->isValid($summary['subtotal'])) {
                return response()->json(['message' => 'الكوبون غير صالح', 'code' => 'INVALID_COUPON'], 422);
            }
            $discountAmount = $coupon->calculateDiscount($summary['subtotal']);
            $couponData = [
                'code'           => $coupon->code,
                'discount_type'  => $coupon->type,
                'discount_value' => number_format((float) $coupon->value, 2, '.', ''),
                'discount_amount'=> number_format((float) $discountAmount, 2, '.', ''),
            ];
        }

        // الحجز الحالي
        $cart = $this->cartService->getCart($owner);

        return response()->json([
            'reservation_extended' => $summary['reservation_extended'],
            'expires_at'           => $summary['expires_at'],
            'seconds_remaining'    => $summary['seconds_remaining'],
            'cart'                 => $this->formatCart($cart),
            'delivery_options'     => $deliveryOptions,
            'active_cities'        => config('gazabella.active_cities'),
            'coupon'               => $couponData,
        ]);
    }

    /**
     * POST /api/v1/orders
     * إنشاء الطلب الفعلي بعد إتمام الدفع
     */
    public function quote(Request $request): JsonResponse
    {
        $data = $request->validate([
            'delivery_option_id' => 'required|integer|exists:delivery_options,id',
            'city' => ['required', Rule::in(config('gazabella.active_cities'))],
            'coupon_code' => 'sometimes|nullable|string',
        ]);
        $delivery = DeliveryOption::active()->findOrFail($data['delivery_option_id']);
        $coupon = !empty($data['coupon_code']) ? Coupon::where('code', strtoupper($data['coupon_code']))->first() : null;
        if (!empty($data['coupon_code']) && !$coupon) return response()->json(['message' => 'الكوبون غير صالح'], 422);
        try {
            return response()->json(['data' => app(\App\Services\CheckoutQuoteService::class)->issue($request->user(), $delivery, $coupon, $data['city'])]);
        } catch (\DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 409);
        }
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'delivery_option_id' => 'required|integer|exists:delivery_options,id',
            'payment_method' => ['required', Rule::in(['cod', 'jawwal_pay'])],
            'quote_token' => 'required|string',
            'coupon_code'        => 'sometimes|nullable|string',
            'notes'              => 'sometimes|nullable|string|max:500',
            'address'            => 'required|array',
            'address.full_name'  => 'required|string|max:100',
            'address.phone'      => 'required|string|max:20',
            'address.city'       => ['required', 'string', Rule::in(config('gazabella.active_cities'))],
            'address.area'       => 'required|string',
            'address.details'    => 'required|string',
            'address.landmark'   => 'sometimes|nullable|string|max:255',
            'address.lat'        => 'sometimes|nullable|numeric|between:-90,90',
            'address.lng'        => 'sometimes|nullable|numeric|between:-180,180',
        ]);

        $key = $request->header('Idempotency-Key');
        validator(['key' => $key], ['key' => 'required|uuid'])->validate();
        $data['request_hash'] = hash('sha256', json_encode($data));
        $data['idempotency_key'] = $key;

        // تحويل address structure → حقول داخلية
        $data['recipient_name']  = $data['address']['full_name'];
        $data['recipient_phone'] = $data['address']['phone'];
        $data['delivery_address'] = [
            'city'    => $data['address']['city'],
            'area'    => $data['address']['area'],
            'details' => $data['address']['details'],
            'landmark' => $data['address']['landmark'] ?? null,
            'lat' => $data['address']['lat'] ?? null,
            'lng' => $data['address']['lng'] ?? null,
        ];

        $owner = $this->resolveOwner($request);

        // خيار التوصيل
        $deliveryOption = DeliveryOption::findOrFail($data['delivery_option_id']);

        $coupon = !empty($data['coupon_code']) ? Coupon::where('code', strtoupper($data['coupon_code']))->first() : null;

        try {
            $order = $this->orderService->createOrder($owner, $data, $deliveryOption, $coupon);
        } catch (\DomainException $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'code'    => 'ORDER_CREATION_FAILED',
            ], 409);
        }

        $order->load([
            'items.variant.product.primaryImage',
            'tracking',
            'payment',
            'deliveryOption',
            'coupon',
        ]);

        return response()->json([
            'data'      => $this->formatOrder($order),
            'next_step' => $order->payment_method === 'jawwal_pay' ? 'POST /api/v1/payments/init' : null,
        ], 201);
    }

    /**
     * GET /api/v1/orders
     * سجل طلبات المستخدم (مصادق عليه فقط)
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $orders = Order::where('user_id', $user->id)
            ->with(['items.variant.product.primaryImage', 'tracking', 'payment', 'deliveryOption', 'coupon'])
            ->latest()
            ->paginate(15);

        $items = collect($orders->items())->map(fn($o) => $this->formatOrder($o));

        return response()->json([
            'data' => $items,
            'meta' => [
                'current_page' => $orders->currentPage(),
                'per_page'     => $orders->perPage(),
                'total'        => $orders->total(),
                'last_page'    => $orders->lastPage(),
            ],
        ]);
    }

    /**
     * GET /api/v1/orders/{orderNumber}
     * تفاصيل طلب واحد (GAZ-2026-XXXX)
     */
    public function show(Request $request, string $orderNumber): JsonResponse
    {
        $user = $request->user();

        $order = Order::where('order_number', $orderNumber)
            ->where('user_id', $user->id)
            ->with([
                'items.variant.product.primaryImage',
                'tracking',
                'payment',
                'deliveryOption',
                'coupon',
            ])
            ->firstOrFail();

        return response()->json([
            'data' => $this->formatOrder($order),
        ]);
    }

    // ─────────────────────────────────────────────────
    // Formatters — sub_orders و commission_amount مخفيَّان
    // ─────────────────────────────────────────────────

    private function formatOrderSummary(Order $order): array
    {
        $latestStatus = $order->tracking->first();

        return [
            'order_number'   => $order->order_number,
            'status'         => $order->status,
            'total'          => (float) $order->total,
            'items_count'    => $order->items->count(),
            'created_at'     => $order->created_at->toIso8601String(),
            'latest_status'  => $latestStatus ? [
                'status'      => $latestStatus->status,
                'description' => $latestStatus->description,
                'at'          => $latestStatus->created_at->toIso8601String(),
            ] : null,
        ];
    }

    /**
     * تنسيق بيانات الطلب حسب مخطط OpenAPI
     *
     * Security: لا يظهر store_id أو commission_amount أو sub_orders أبداً
     */
    private function formatOrder(Order $order): array
    {
        // عنوان التوصيل من الحقول المفككة
        $addr = $order->delivery_address; // array: {city, area, details}

        // خيار التوصيل
        $delivOpt = $order->relationLoaded('deliveryOption')
            ? $order->deliveryOption
            : null;

        // حالة الدفع
        $payment = $order->relationLoaded('payment') ? $order->payment : null;
        $paymentStatus = $payment ? $payment->status : 'unpaid';

        // كود الكوبون (من علاقة coupon أو null)
        $coupon = $order->relationLoaded('coupon') ? $order->coupon : null;

        // العناصر (snapshot — بدون store_id أو sub_order_id)
        $items = $order->relationLoaded('items')
            ? $order->items->map(fn($item) => [
                'id'                 => $item->id,
                'product_name'       => $item->product_name,
                'variant_name'       => $item->variant_name,
                'unit_price'         => number_format((float) $item->unit_price, 2, '.', ''),
                'quantity'           => $item->quantity,
                'subtotal'           => number_format((float) $item->total, 2, '.', ''),
                'thumbnail_url'      => $item->relationLoaded('variant')
                    ? ($item->variant?->relationLoaded('product')
                        ? ($item->variant->product?->primaryImage?->url ?? null)
                        : null)
                    : null,
                'product_variant_id' => $item->product_variant_id,
            ])
            : [];

        // سجل الحالات
        $tracking = $order->relationLoaded('tracking')
            ? $order->tracking->map(fn($t) => [
                'status'     => $t->status,
                'note'       => $t->description,
                'created_at' => $t->created_at?->toIso8601String(),
            ])
            : [];

        return [
            'id'              => $order->id,
            'order_number'    => $order->order_number,
            'status'          => $order->status,
            'items'           => $items,
            'subtotal'        => number_format((float) $order->subtotal, 2, '.', ''),
            'delivery_fee'    => number_format((float) $order->delivery_fee, 2, '.', ''),
            'discount_amount' => number_format((float) $order->discount_amount, 2, '.', ''),
            'total'           => number_format((float) $order->total, 2, '.', ''),
            'delivery_option' => $delivOpt ? [
                'name'           => $delivOpt->name,
                'estimated_days' => $delivOpt->estimated_days,
            ] : null,
            'address'         => [
                'full_name' => $order->recipient_name,
                'phone'     => $order->recipient_phone,
                'city'      => $addr['city'] ?? null,
                'area'      => $addr['area'] ?? null,
                'details'   => $addr['details'] ?? null,
                'landmark'  => $addr['landmark'] ?? null,
                'lat'       => $addr['lat'] ?? null,
                'lng'       => $addr['lng'] ?? null,
            ],
            'payment_status'  => $paymentStatus,
            'payment_method'  => $order->payment_method,
            'tracking'        => $tracking,
            'coupon_code'     => $coupon?->code,
            'notes'           => $order->notes,
            'created_at'      => $order->created_at->toIso8601String(),
        ];
    }
}
