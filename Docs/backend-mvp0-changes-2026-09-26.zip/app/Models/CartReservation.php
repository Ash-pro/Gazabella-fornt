<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CartReservation extends Model
{
    public $timestamps = false;
    const CREATED_AT = 'created_at';

    protected $fillable = [
        'cart_item_id', 'product_variant_id',
        'quantity', 'expires_at', 'extended_at',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'extended_at' => 'datetime',
        'created_at' => 'datetime',
    ];

    public function cartItem()
    {
        return $this->belongsTo(CartItem::class);
    }

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function isExpired(): bool
    {
        return $this->expires_at->isPast();
    }

    public function canBeExtended(): bool
    {
        // مرة واحدة فقط — إذا extended_at null معناته لم يُمدَّد بعد
        return $this->extended_at === null && !$this->isExpired();
    }

    public function secondsRemaining(): int
    {
        return max(0, (int) floor(now()->diffInSeconds($this->expires_at, false)));
    }
}
