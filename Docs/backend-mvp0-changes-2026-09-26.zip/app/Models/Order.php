<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_number', 'user_id', 'guest_session_id', 'status',
        'recipient_name', 'recipient_phone', 'delivery_address',
        'delivery_option_id', 'delivery_fee', 'subtotal',
        'discount_amount', 'total', 'coupon_id', 'notes',
        'payment_method', 'idempotency_key', 'request_hash',
    ];

    protected $casts = [
        'delivery_address' => 'array',
        'delivery_fee' => 'decimal:2',
        'subtotal' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'total' => 'decimal:2',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function subOrders()
    {
        return $this->hasMany(SubOrder::class);
    }

    public function items()
    {
        return $this->hasManyThrough(OrderItem::class, SubOrder::class);
    }

    public function tracking()
    {
        return $this->hasMany(OrderTracking::class)->latest('created_at');
    }

    public function payment()
    {
        return $this->hasOne(Payment::class)->latest();
    }

    public function deliveryOption()
    {
        return $this->belongsTo(DeliveryOption::class);
    }

    public function coupon()
    {
        return $this->belongsTo(Coupon::class);
    }

    /**
     * توليد رقم الطلب: GAZ-2026-0001
     */
    public static function generateOrderNumber(): string
    {
        $year = now()->year;
        $db = \Illuminate\Support\Facades\DB::table('order_sequences');
        $db->insertOrIgnore(['year' => $year, 'value' => static::whereYear('created_at', $year)->max('id') ?? 0]);
        $sequence = $db->where('year', $year)->lockForUpdate()->first();
        $next = $sequence->value + 1;
        $db->where('year', $year)->update(['value' => $next]);
        return sprintf('GAZ-%d-%04d', $year, $next);
    }
}
