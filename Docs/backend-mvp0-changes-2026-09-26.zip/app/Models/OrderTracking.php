<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderTracking extends Model
{
    protected $table = 'order_tracking';
    protected $casts = ['created_at' => 'datetime'];
    public $timestamps = true;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = null;

    protected $fillable = ['order_id', 'status', 'description'];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
