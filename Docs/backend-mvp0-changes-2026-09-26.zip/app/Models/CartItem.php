<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CartItem extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'guest_session_id', 'product_variant_id', 'quantity'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function guestSession()
    {
        return $this->belongsTo(GuestSession::class);
    }

    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }

    public function reservation()
    {
        return $this->hasOne(CartReservation::class);
    }

    public function hasActiveReservation(): bool
    {
        return $this->reservation()->where('expires_at', '>', now())->exists();
    }
}
