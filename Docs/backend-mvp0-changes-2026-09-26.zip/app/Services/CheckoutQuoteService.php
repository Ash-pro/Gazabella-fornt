<?php

namespace App\Services;

use App\Models\CartItem;
use App\Models\Coupon;
use App\Models\DeliveryOption;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Crypt;

class CheckoutQuoteService
{
    public function snapshot(Collection $items, DeliveryOption $delivery, ?Coupon $coupon, string $city): array
    {
        $subtotal = (int) $items->sum(fn ($item) => (int) round((float) $item->variant->price * 100) * $item->quantity);
        if ($coupon && !$coupon->isValid($subtotal / 100)) throw new \DomainException('الكوبون غير صالح.');
        $discount = $coupon ? (int) round($coupon->calculateDiscount($subtotal / 100) * 100) : 0;
        $fee = (int) round((float) $delivery->fee * 100);
        return [
            'lines' => $items->sortBy('id')->map(fn ($item) => [
                $item->id, $item->product_variant_id, $item->quantity, (string) $item->variant->price,
            ])->values()->all(),
            'delivery_option_id' => $delivery->id, 'city' => $city,
            'coupon' => $coupon?->code,
            'subtotal' => number_format($subtotal / 100, 2, '.', ''),
            'delivery_fee' => number_format($fee / 100, 2, '.', ''),
            'discount_amount' => number_format($discount / 100, 2, '.', ''),
            'total' => number_format(($subtotal + $fee - $discount) / 100, 2, '.', ''),
            'currency' => 'ILS',
        ];
    }

    public function issue(User $user, DeliveryOption $delivery, ?Coupon $coupon, string $city): array
    {
        $items = CartItem::where('user_id', $user->id)->with(['variant', 'reservation'])->get();
        if ($items->isEmpty()) throw new \DomainException('السلة فارغة.');
        $expiry = now()->addMinutes(5);
        foreach ($items as $item) {
            if (!$item->reservation || $item->reservation->isExpired() || $item->reservation->quantity !== $item->quantity) {
                throw new \DomainException('أعد حجز السلة قبل مراجعة الطلب.');
            }
            if ($item->reservation->expires_at->lt($expiry)) $expiry = $item->reservation->expires_at;
        }
        $snapshot = $this->snapshot($items, $delivery, $coupon, $city);
        $token = Crypt::encryptString(json_encode([
            'user_id' => $user->id, 'expires' => $expiry->timestamp,
            'fingerprint' => hash('sha256', json_encode($snapshot)),
        ], JSON_THROW_ON_ERROR));
        unset($snapshot['lines']);
        return [...$snapshot, 'quote_token' => $token, 'expires_at' => $expiry->toIso8601String()];
    }

    public function verify(string $token, int $userId, array $snapshot): void
    {
        try {
            $quote = json_decode(Crypt::decryptString($token), true, 512, JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            throw new \DomainException('عرض السعر غير صالح — أعد المراجعة.');
        }
        if (($quote['user_id'] ?? null) !== $userId || ($quote['expires'] ?? 0) <= now()->timestamp
            || !hash_equals($quote['fingerprint'] ?? '', hash('sha256', json_encode($snapshot)))) {
            throw new \DomainException('انتهى عرض السعر أو تغيرت السلة أو الرسوم — أعد المراجعة قبل التأكيد.');
        }
    }
}
