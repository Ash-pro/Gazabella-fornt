<?php

namespace App\Services;

use App\Events\ReservationExpired;
use App\Events\StockDepleted;
use App\Models\CartItem;
use App\Models\CartReservation;
use App\Models\ProductVariant;
use Illuminate\Support\Facades\DB;

class ReservationService
{
    private const TTL_MINUTES = 15;
    private const MAX_TOTAL_MINUTES = 30; // 15 initial + 15 extension

    /**
     * إنشاء حجز جديد لـ cart_item
     */
    public function reserve(CartItem $item): CartReservation
    {
        return DB::transaction(function () use ($item) {
            $item = CartItem::lockForUpdate()->findOrFail($item->id);
            $variant = ProductVariant::lockForUpdate()->findOrFail($item->product_variant_id);

            $existing = CartReservation::where('cart_item_id', $item->id)->lockForUpdate()->first();
            if ($existing && !$existing->isExpired() && $existing->quantity === $item->quantity) {
                return $existing;
            }
            if ($existing) {
                $this->release($existing);
                $variant->refresh();
            }

            if (!$variant->isAvailable($item->quantity)) {
                throw new \DomainException("المنتج غير متوفر بالكمية المطلوبة");
            }

            $variant->increment('reserved_quantity', $item->quantity);

            $reservation = CartReservation::create([
                'cart_item_id'       => $item->id,
                'product_variant_id' => $item->product_variant_id,
                'quantity'           => $item->quantity,
                'expires_at'         => now()->addMinutes(self::TTL_MINUTES),
            ]);

            if ($variant->fresh()->available_quantity === 0) {
                event(new StockDepleted($variant));
            }

            return $reservation;
        });
    }

    /**
     * Heartbeat — read-only، لا يُمدد الحجز
     * يُستخدم فقط لإعلام العميل بالوقت المتبقي
     */
    public function heartbeat(CartItem $item): array
    {
        $reservation = $item->reservation;

        if (!$reservation) {
            return ['reserved' => false, 'seconds_remaining' => 0];
        }

        return [
            'reserved'          => !$reservation->isExpired(),
            'seconds_remaining' => $reservation->secondsRemaining(),
            'expires_at'        => $reservation->expires_at->toIso8601String(),
        ];
    }

    /**
     * تمديد الحجز — مرة واحدة فقط عند POST /orders/checkout/begin
     */
    public function extend(CartReservation $reservation): CartReservation
    {
        return DB::transaction(function () use ($reservation) {
            CartItem::whereKey($reservation->cart_item_id)->lockForUpdate()->firstOrFail();
            $locked = CartReservation::lockForUpdate()->findOrFail($reservation->id);
            if ($locked->isExpired()) throw new \DomainException('انتهى الحجز، أعد حجز السلة.');
            if ($locked->extended_at !== null) return $locked;
            $locked->update([
                'expires_at' => $locked->expires_at->addMinutes(self::TTL_MINUTES),
                'extended_at' => now(),
            ]);
            return $locked->fresh();
        });
    }

    /**
     * إلغاء الحجز وإعادة المخزون
     */
    public function release(CartReservation $reservation): void
    {
        DB::transaction(function () use ($reservation) {
            CartItem::whereKey($reservation->cart_item_id)->lockForUpdate()->first();
            $variant = ProductVariant::lockForUpdate()->findOrFail($reservation->product_variant_id);
            $locked = CartReservation::lockForUpdate()->find($reservation->id);
            if (!$locked) return;
            $variant->update(['reserved_quantity' => max(0, $variant->reserved_quantity - $locked->quantity)]);
            $locked->delete();
        });
    }

    /**
     * تشغيل cleanup للحجوزات المنتهية (Scheduler)
     */
    public function cleanExpired(): int
    {
        $expired = CartReservation::where('expires_at', '<=', now())->get();
        $released = 0;
        foreach ($expired as $reservation) {
            $released += DB::transaction(function () use ($reservation) {
                CartItem::whereKey($reservation->cart_item_id)->lockForUpdate()->first();
                $locked = CartReservation::find($reservation->id);
                if (!$locked || !$locked->isExpired()) return 0;
                $this->release($locked);
                return 1;
            });
        }
        return $released;
    }
}
