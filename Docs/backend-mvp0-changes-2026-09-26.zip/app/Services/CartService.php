<?php

namespace App\Services;

use App\Models\CartItem;
use App\Models\GuestSession;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class CartService
{
    public function __construct(
        private readonly ReservationService $reservationService
    ) {}

    /**
     * جلب محتوى السلة مع حالة الحجز
     */
    public function getCart(User|GuestSession $owner): array
    {
        $items = $this->getItems($owner)->with(['variant.product.primaryImage'])->get();

        $cartItems = $items->map(function (CartItem $item) {
            $variant = $item->variant;
            $reservation = $item->reservation;

            return [
                'cart_item_id'   => $item->id,
                'product_id'     => $variant->product_id,
                'product_slug'   => $variant->product->slug,
                'stock'          => $variant->available_quantity + ($reservation?->quantity ?? 0),
                'product_name'   => $variant->product->name,
                'variant_id'     => $variant->id,
                'variant_name'   => $variant->name,
                'attributes'     => $variant->attributes,
                'unit_price'     => $variant->price,
                'quantity'       => $item->quantity,
                'subtotal'       => round($variant->price * $item->quantity, 2),
                'image_url'      => $variant->product->primaryImage?->url,
                'is_reserved'    => (bool) $reservation && !$reservation->isExpired(),
                'reservation'    => $reservation && !$reservation->isExpired() ? [
                    'seconds_remaining' => $reservation->secondsRemaining(),
                    'expires_at'        => $reservation->expires_at->toIso8601String(),
                    'can_extend'        => $reservation->canBeExtended(),
                ] : null,
            ];
        });

        return [
            'items'    => $cartItems,
            'summary'  => [
                'item_count' => $items->sum('quantity'),
                'subtotal'   => $cartItems->sum('subtotal'),
            ],
        ];
    }

    /**
     * إضافة منتج للسلة
     */
    public function addItem(User|GuestSession $owner, int $variantId, int $quantity): CartItem
    {
        return DB::transaction(function () use ($owner, $variantId, $quantity) {
            // Serialize changes for the same owner, including creation of a new cart line.
            $owner->newQuery()->whereKey($owner->id)->lockForUpdate()->firstOrFail();
            [$ownerKey, $ownerId] = $this->ownerKey($owner);
            $item = CartItem::where($ownerKey, $ownerId)
                ->where('product_variant_id', $variantId)->lockForUpdate()
                ->first();
            $variant = ProductVariant::active()->lockForUpdate()->findOrFail($variantId);
            $newQuantity = ($item?->quantity ?? 0) + $quantity;
            $ownReserved = $item?->reservation?->quantity ?? 0;
            if ($newQuantity > 10 || $quantity < 1 || $newQuantity > $variant->available_quantity + $ownReserved) {
                throw new \DomainException('الكمية المطلوبة غير متوفرة أو تتجاوز الحد 10.');
            }
            if ($item) {
                if ($item->reservation) $this->reservationService->release($item->reservation);
                $item->update(['quantity' => $newQuantity]);
            } else {
                $item = CartItem::create([
                    $ownerKey             => $ownerId,
                    'product_variant_id'  => $variantId,
                    'quantity'            => $quantity,
                ]);
            }

            return $item;
        });
    }

    public function updateItem(CartItem $item, int $quantity): void
    {
        DB::transaction(function () use ($item, $quantity) {
            $item = CartItem::lockForUpdate()->findOrFail($item->id);
            $variant = ProductVariant::active()->lockForUpdate()->findOrFail($item->product_variant_id);
            $reservation = $item->reservation;
            if ($quantity < 1 || $quantity > 10 || $quantity > $variant->available_quantity + ($reservation?->quantity ?? 0)) {
                throw new \DomainException('الكمية المطلوبة غير متوفرة أو تتجاوز الحد 10.');
            }
            if ($quantity === $item->quantity) return;
            if ($reservation) $this->reservationService->release($reservation);
            $item->update(['quantity' => $quantity]);
        });
    }

    /**
     * حذف منتج من السلة + إلغاء حجزه
     */
    public function removeItem(CartItem $item): void
    {
        DB::transaction(function () use ($item) {
            $item = CartItem::lockForUpdate()->findOrFail($item->id);
            if ($reservation = $item->reservation) {
                $this->reservationService->release($reservation);
            }
            $item->delete();
        });
    }

    private function getItems(User|GuestSession $owner)
    {
        [$key, $id] = $this->ownerKey($owner);
        return CartItem::where($key, $id)->with('reservation');
    }

    private function ownerKey(User|GuestSession $owner): array
    {
        return $owner instanceof User
            ? ['user_id', $owner->id]
            : ['guest_session_id', $owner->id];
    }
}
