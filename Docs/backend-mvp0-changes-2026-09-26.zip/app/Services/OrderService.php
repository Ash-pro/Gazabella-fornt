<?php

namespace App\Services;

use App\Events\OrderStatusChanged;
use App\Models\CartItem;
use App\Models\CartReservation;
use App\Models\Coupon;
use App\Models\DeliveryOption;
use App\Models\GuestSession;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderTracking;
use App\Models\SubOrder;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class OrderService
{
    public function __construct(
        private readonly ReservationService $reservationService
    ) {}

    /**
     * POST /orders/checkout/begin
     * يمدد الحجوزات مرة واحدة ويحضّر ملخص الطلب
     */
    public function beginCheckout(User|GuestSession $owner): array
    {
        return DB::transaction(function () use ($owner) {
        [$ownerKey, $ownerId] = $this->ownerKey($owner);

        $items = CartItem::with(['reservation', 'variant.product'])
            ->where($ownerKey, $ownerId)->orderBy('id')->lockForUpdate()
            ->get();

        if ($items->isEmpty()) throw new \DomainException("السلة فارغة");

        // حساب الـ subtotal
        $subtotal = $items->sum(fn($i) => $i->variant->price * $i->quantity);

        // تمديد الحجوزات (مرة واحدة) — نتابع إذا حصل تمديد فعلي
        $reservationExtended = false;
        $activeReservation   = null;

        $items->each(function (CartItem $item) use (&$reservationExtended, &$activeReservation) {
            if (!$item->reservation || $item->reservation->isExpired() || $item->reservation->quantity !== $item->quantity) {
                throw new \DomainException('انتهت مدة الحجز أو تغيرت السلة — يرجى إعادة الحجز');
            }
            if ($reservation = $item->reservation) {
                if ($reservation->canBeExtended()) {
                    $reservation = $this->reservationService->extend($reservation);
                    $reservationExtended = true;
                }
                // نحفظ أول حجز نشط (لإعادة reserved_until و seconds_remaining)
                if (!$activeReservation || $reservation->expires_at->lt($activeReservation->expires_at)) {
                    $activeReservation = $reservation;
                }
            }
        });

        return [
            'items'                => $items,
            'reservation_extended' => $reservationExtended,
            'expires_at'           => $activeReservation
                ? $activeReservation->expires_at->toIso8601String()
                : null,
            'seconds_remaining'    => $activeReservation
                ? $activeReservation->secondsRemaining()
                : null,
            'subtotal'             => $subtotal,
        ];
        });
    }

    /**
     * POST /orders — إنشاء الطلب الفعلي
     */
    public function createOrder(
        User|GuestSession $owner,
        array $data,
        DeliveryOption $deliveryOption,
        ?Coupon $coupon = null
    ): Order {
        return DB::transaction(function () use ($owner, $data, $deliveryOption, $coupon) {
            $owner->newQuery()->whereKey($owner->id)->lockForUpdate()->firstOrFail();
            [$ownerKey, $ownerId] = $this->ownerKey($owner);

            $existing = Order::where($ownerKey, $ownerId)->where('idempotency_key', $data['idempotency_key'])->first();
            if ($existing) {
                if (!hash_equals($existing->request_hash, $data['request_hash'])) {
                    throw new \DomainException('استُخدم مفتاح المحاولة لطلب مختلف.');
                }
                return $existing;
            }

            $cartItems = CartItem::with(['variant.product', 'reservation'])
                ->where($ownerKey, $ownerId)->orderBy('id')->lockForUpdate()
                ->get();

            if ($cartItems->isEmpty()) throw new \DomainException("السلة فارغة");

            $variants = \App\Models\ProductVariant::whereIn('id', $cartItems->pluck('product_variant_id'))
                ->orderBy('id')->lockForUpdate()->get()->keyBy('id');
            foreach ($cartItems as $item) {
                $variant = $variants->get($item->product_variant_id);
                $reservation = CartReservation::where('cart_item_id', $item->id)->lockForUpdate()->first();
                if (!$variant || !$variant->is_active || !$variant->product->is_active || !$reservation || $reservation->isExpired()
                    || $reservation->quantity !== $item->quantity || $item->quantity > 10
                    || $variant->stock_quantity < $item->quantity || $variant->reserved_quantity < $item->quantity) {
                    throw new \DomainException('انتهى الحجز أو تغير المخزون — أعد مراجعة السلة.');
                }
                $item->setRelation('variant', $variant);
                $item->setRelation('reservation', $reservation);
            }
            $deliveryOption = DeliveryOption::active()->lockForUpdate()->findOrFail($deliveryOption->id);
            if ($coupon) $coupon = Coupon::lockForUpdate()->findOrFail($coupon->id);

            // حساب الإجماليات
            $subtotal = $cartItems->sum(fn($i) => $i->variant->price * $i->quantity);
            if ($coupon && !$coupon->isValid($subtotal)) throw new \DomainException('الكوبون لم يعد صالحًا.');
            $discount = $coupon ? $coupon->calculateDiscount($subtotal) : 0;
            $total = round($subtotal + $deliveryOption->fee - $discount, 2);
            $snapshot = app(CheckoutQuoteService::class)->snapshot($cartItems, $deliveryOption, $coupon, $data['address']['city']);
            app(CheckoutQuoteService::class)->verify($data['quote_token'], $ownerId, $snapshot);

            // إنشاء الطلب
            $order = Order::create([
                'order_number'      => Order::generateOrderNumber(),
                $ownerKey           => $ownerId,
                'status'            => 'pending',
                'recipient_name'    => $data['recipient_name'],
                'recipient_phone'   => $data['recipient_phone'],
                'delivery_address'  => $data['delivery_address'],
                'delivery_option_id'=> $deliveryOption->id,
                'delivery_fee'      => $deliveryOption->fee,
                'subtotal'          => $subtotal,
                'discount_amount'   => $discount,
                'total'             => $total,
                'coupon_id'         => $coupon?->id,
                'notes'             => $data['notes'] ?? null,
                'payment_method'    => $data['payment_method'],
                'idempotency_key'   => $data['idempotency_key'],
                'request_hash'      => $data['request_hash'],
            ]);

            // توزيع على sub_orders per-store
            $byStore = $cartItems->groupBy(fn($i) => $i->variant->product->store_id);

            foreach ($byStore as $storeId => $storeItems) {
                $storeSubtotal = $storeItems->sum(fn($i) => $i->variant->price * $i->quantity);

                $subOrder = SubOrder::create([
                    'order_id'          => $order->id,
                    'store_id'          => $storeId,
                    'status'            => 'pending',
                    'subtotal'          => $storeSubtotal,
                    'commission_amount' => 0, // يُحسب لاحقاً
                ]);

                foreach ($storeItems as $item) {
                    OrderItem::create([
                        'sub_order_id'       => $subOrder->id,
                        'product_variant_id' => $item->product_variant_id,
                        'product_name'       => $item->variant->product->name,
                        'variant_name'       => $item->variant->name,
                        'unit_price'         => $item->variant->price,
                        'quantity'           => $item->quantity,
                        'total'              => round($item->variant->price * $item->quantity, 2),
                    ]);

                    // تحويل الحجز → مؤكد (نقل من reserved إلى sold)
                    if ($reservation = $item->reservation) {
                        $item->variant->decrement('reserved_quantity', $reservation->quantity);
                        $item->variant->decrement('stock_quantity', $reservation->quantity);
                        $reservation->delete();
                    }

                    $item->delete();
                }
            }

            // إضافة أول tracking entry
            OrderTracking::create([
                'order_id'    => $order->id,
                'status'      => 'pending',
                'description' => $data['payment_method'] === 'cod' ? 'تم إنشاء الطلب — الدفع عند الاستلام' : 'تم إنشاء الطلب — في انتظار الدفع',
            ]);

            if ($coupon) {
                $coupon->increment('used_count');
            }

            DB::afterCommit(fn () => event(new OrderStatusChanged($order, 'pending')));

            return $order;
        });
    }

    public function updateStatus(Order $order, string $status, string $description): Order
    {
        $order->update(['status' => $status]);

        OrderTracking::create([
            'order_id'    => $order->id,
            'status'      => $status,
            'description' => $description,
        ]);

        DB::afterCommit(fn () => event(new OrderStatusChanged($order, $status)));

        return $order->fresh();
    }

    private function ownerKey(User|GuestSession $owner): array
    {
        return $owner instanceof User
            ? ['user_id', $owner->id]
            : ['guest_session_id', $owner->id];
    }
}
