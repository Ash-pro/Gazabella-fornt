<?php
namespace App\Services;

use App\Events\PaymentConfirmed;
use App\Events\PaymentFailed;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Support\Facades\DB;

class PaymentService
{
    public function initiate(Order $order): array
    {
        return DB::transaction(function () use ($order) {
            $order = Order::lockForUpdate()->findOrFail($order->id);
            if ($order->payment_method !== 'jawwal_pay' || $order->status !== 'pending') {
                throw new \RuntimeException('هذا الطلب غير قابل للدفع الإلكتروني.');
            }
            // Production integration belongs to MVP1; never fabricate a production payment session.
            if (!config('services.jawwal_pay.sandbox') || !app()->environment(['local', 'testing'])) {
                throw new \RuntimeException('الدفع الإلكتروني الإنتاجي غير مفعّل.');
            }
            $payment = Payment::where('order_id', $order->id)->latest('id')->lockForUpdate()->first();
            if ($payment && $payment->status === 'completed') throw new \RuntimeException('تم دفع هذا الطلب مسبقًا.');
            if (!$payment || $payment->status !== 'pending' || !$payment->expires_at || $payment->expires_at->isPast()) {
                // Keep one payment record for this order; its gateway reference remains stable on retry.
                $payment ??= new Payment(['order_id' => $order->id]);
                $payment->fill([
                    'provider' => 'jawwal_pay', 'amount' => $order->total, 'status' => 'pending',
                    'initiated_at' => now(), 'expires_at' => now()->addMinutes(30),
                    'payment_url' => 'https://sandbox.jawwalpay.ps/pay?ref=' . rawurlencode($order->order_number),
                ])->save();
            }
            return ['payment_id' => $payment->id, 'payment_url' => $payment->payment_url,
                'expires_at' => $payment->expires_at->toIso8601String(), 'sandbox' => true];
        });
    }

    public function handleWebhook(array $payload): void
    {
        validator($payload, [
            'transaction_id' => 'required|string|max:255',
            'merchant_ref' => 'required|string',
            'status' => 'required|in:SUCCESS,FAILED',
            'amount' => 'required|numeric|min:0',
        ])->validate();
        DB::transaction(function () use ($payload) {
            $order = Order::where('order_number', $payload['merchant_ref'])->lockForUpdate()->firstOrFail();
            $payment = Payment::where('order_id', $order->id)->latest('id')->lockForUpdate()->firstOrFail();
            if ($order->payment_method !== 'jawwal_pay' || (int) round($payload['amount'] * 100) !== (int) round($payment->amount * 100)) {
                throw new \DomainException('مبلغ الدفع أو طريقته لا يطابق الطلب.');
            }
            if ($payment->provider_transaction_id && $payment->provider_transaction_id !== $payload['transaction_id']) {
                throw new \DomainException('مرجع الدفع لا يطابق المحاولة المسجلة.');
            }
            // Duplicate or delayed notifications cannot roll back a completed payment.
            if (in_array($payment->status, ['completed', 'refunded'], true)) return;
            if ($order->status !== 'pending') throw new \DomainException('هذا الطلب غير قابل للدفع.');
            $success = $payload['status'] === 'SUCCESS';
            $payment->update([
                'provider_transaction_id' => $payload['transaction_id'], 'provider_response' => $payload,
                'status' => $success ? 'completed' : 'failed',
                $success ? 'completed_at' : 'failed_at' => now(),
            ]);
            if ($success) {
                app(OrderService::class)->updateStatus($order, 'confirmed', 'تم تأكيد الدفع');
                DB::afterCommit(fn () => event(new PaymentConfirmed($order, $payment)));
            } else {
                DB::afterCommit(fn () => event(new PaymentFailed($order, $payment)));
            }
        });
    }
}
