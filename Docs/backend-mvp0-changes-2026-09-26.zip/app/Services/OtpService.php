<?php

namespace App\Services;

use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Str;

/**
 * OTP Service
 * - 6 أرقام عشوائية
 * - bcrypt في Redis
 * - TTL = 5 دقائق (300 ثانية)
 * - قرار backend نهائي — non-negotiable
 */
class OtpService
{
    private const PREFIX = 'otp:';
    private const TTL = 300; // 5 minutes

    public function send(string $phone): string
    {
        $otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        // في وضع الاختبار — تخطي Redis وإعادة test_code
        if (config('gazabella.otp.test_mode')) {
            return config('gazabella.otp.test_code');
        }

        $hash = bcrypt($otp);
        Redis::setex(self::PREFIX . $phone, self::TTL, $hash);

        // TODO: إرسال OTP عبر SMS provider

        return $otp;
    }

    public function verify(string $phone, string $otp): bool
    {
        if (config('gazabella.otp.test_mode')) {
            return hash_equals((string) config('gazabella.otp.test_code'), $otp);
        }
        $key = self::PREFIX . $phone;
        $hash = Redis::get($key);

        if (!$hash) return false;

        $valid = password_verify($otp, $hash);

        if ($valid) {
            Redis::del($key); // single-use
        }

        return $valid;
    }

    public function ttlRemaining(string $phone): int
    {
        // في وضع الاختبار — Redis غير متاح، نرجع 0 دائماً
        if (config('gazabella.otp.test_mode')) {
            return 0;
        }

        return max(0, Redis::ttl(self::PREFIX . $phone));
    }
}
