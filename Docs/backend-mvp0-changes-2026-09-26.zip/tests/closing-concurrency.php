<?php
// Run only against the dedicated temporary MariaDB/MySQL closure database.
require __DIR__.'/../vendor/autoload.php';
$app = require __DIR__.'/../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\{CartItem, CartReservation, DeliveryOption, Order, ProductVariant, User};
use App\Services\{CartService, CheckoutQuoteService, OrderService, ReservationService};
use Illuminate\Support\Facades\{Artisan, DB};
use Illuminate\Support\Str;
use Symfony\Component\Process\Process;

if (!app()->environment('testing') || DB::getDriverName() !== 'mysql' || DB::connection()->getDatabaseName() !== 'gazabella_closing_races') {
    throw new RuntimeException('Use only the isolated gazabella_closing_races database in testing.');
}
function check(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }
if (($argv[1] ?? '') === 'worker') {
    $file = $argv[2]; $case = json_decode(file_get_contents($file), true);
    touch($file.'.ready');
    $deadline = microtime(true) + 20;
    while (!file_exists($case['go'])) { if (microtime(true) > $deadline) throw new RuntimeException('Barrier timeout'); usleep(10000); }
    try {
        $value = match ($case['action']) {
            'reserve' => app(ReservationService::class)->reserve(CartItem::findOrFail($case['id']))->id,
            'cleanup' => app(ReservationService::class)->cleanExpired(),
            'order' => app(OrderService::class)->createOrder(User::findOrFail($case['user']), $case['data'], DeliveryOption::findOrFail($case['delivery']))->order_number,
        };
        echo json_encode(['ok' => true, 'value' => $value]);
    } catch (DomainException $error) { echo json_encode(['ok' => false, 'conflict' => true]); }
    exit;
}

function race(array $cases): array {
    $dir = sys_get_temp_dir().'/gazabella-race-'.Str::uuid(); mkdir($dir);
    $processes = [];
    try {
        foreach ($cases as $i => $case) {
            $file = "$dir/$i.json";
            file_put_contents($file, json_encode($case + ['go' => "$dir/go"]));
            $process = new Process([PHP_BINARY, __FILE__, 'worker', $file], base_path(), null, null, 30);
            $process->start(); $processes[] = $process;
        }
        $deadline = microtime(true) + 20;
        do {
            $ready = true;
            foreach ($cases as $i => $_) $ready = $ready && file_exists("$dir/$i.json.ready");
            if (microtime(true) > $deadline) throw new RuntimeException('Workers did not reach barrier');
            usleep(10000);
        } while (!$ready);
        touch("$dir/go");
        $results = [];
        foreach ($processes as $process) {
            $process->wait();
            check($process->isSuccessful(), $process->getErrorOutput().$process->getOutput());
            $results[] = json_decode($process->getOutput(), true, 512, JSON_THROW_ON_ERROR);
        }
        return $results;
    } finally { foreach ($processes as $process) if ($process->isRunning()) $process->stop(); }
}

function orderCase(User $user, ProductVariant $variant): array {
    $item = app(CartService::class)->addItem($user, $variant->id, 1);
    app(ReservationService::class)->reserve($item);
    app(OrderService::class)->beginCheckout($user);
    $delivery = DeliveryOption::active()->firstOrFail();
    $quote = app(CheckoutQuoteService::class)->issue($user, $delivery, null, 'خانيونس');
    $data = ['quote_token' => $quote['quote_token'], 'payment_method' => 'cod',
        'idempotency_key' => (string) Str::uuid(), 'request_hash' => hash('sha256', $quote['quote_token']),
        'address' => ['city' => 'خانيونس'], 'recipient_name' => 'Local concurrency test',
        'recipient_phone' => '+970599123456', 'delivery_address' => ['city' => 'خانيونس', 'area' => 'test', 'details' => 'test']];
    return ['action' => 'order', 'user' => $user->id, 'delivery' => $delivery->id, 'data' => $data];
}

check(!\Illuminate\Support\Facades\Schema::hasTable('orders'), 'Use a fresh empty closure database; existing data is never cleared by this script.');
Artisan::call('migrate', ['--force' => true]);
Artisan::call('db:seed', ['--force' => true]);
$variant = ProductVariant::firstOrFail();
$variant->update(['stock_quantity' => 1, 'reserved_quantity' => 0]);
$a = app(CartService::class)->addItem(User::factory()->create(), $variant->id, 1);
$b = app(CartService::class)->addItem(User::factory()->create(), $variant->id, 1);
$results = race([['action' => 'reserve', 'id' => $a->id], ['action' => 'reserve', 'id' => $b->id]]);
check(count(array_filter($results, fn ($r) => $r['ok'])) === 1, 'Last unit reserved more than once');
check($variant->fresh()->reserved_quantity === 1 && CartReservation::count() === 1, 'Reservation stock drift');
echo "PASS simultaneous last-unit reservation\n";
CartReservation::query()->update(['expires_at' => now()->subMinute()]);
$results = race([['action' => 'cleanup'], ['action' => 'cleanup']]);
check(array_sum(array_column($results, 'value')) === 1 && $variant->fresh()->reserved_quantity === 0, 'Duplicate cleanup decremented twice');
echo "PASS simultaneous reservation cleanup\n";
$variant->update(['stock_quantity' => 10]);
$case = orderCase(User::factory()->create(), $variant);
$results = race([$case, $case]);
check($results[0]['ok'] && $results[1]['ok'] && $results[0]['value'] === $results[1]['value'], 'Concurrent idempotency failed');
check(Order::count() === 1 && $variant->fresh()->stock_quantity === 9, 'Duplicate order consumed stock twice');
echo "PASS simultaneous duplicate checkout\n";
$cases = [orderCase(User::factory()->create(), $variant), orderCase(User::factory()->create(), $variant)];
$results = race($cases);
check($results[0]['ok'] && $results[1]['ok'] && $results[0]['value'] !== $results[1]['value'], 'Order numbers collided');
check(Order::count() === 3 && $variant->fresh()->stock_quantity === 7 && $variant->fresh()->reserved_quantity === 0, 'Concurrent checkout inventory drift');
echo "PASS simultaneous distinct checkout\n";
$item = app(CartService::class)->addItem(User::factory()->create(), $variant->id, 1);
app(ReservationService::class)->reserve($item);
CartReservation::query()->update(['expires_at' => now()->subMinute()]);
Artisan::call('schedule:run');
check(CartReservation::count() === 0 && $variant->fresh()->reserved_quantity === 0, 'Scheduler did not clean expired reservations');
echo "PASS actual scheduler cleanup\n";

// Upgrade existing legacy statuses, preserving the order rows and amounts.
$before = Order::orderBy('id')->get(['id', 'total'])->toArray();
DB::statement("ALTER TABLE orders MODIFY status ENUM('pending_payment','paid','pending','confirmed','processing','shipped','delivered','cancelled','refunded') NOT NULL DEFAULT 'pending'");
$ids = Order::orderBy('id')->pluck('id');
DB::table('orders')->where('id', $ids[0])->update(['status' => 'pending_payment']);
DB::table('orders')->where('id', $ids[1])->update(['status' => 'paid']);
$migration = require database_path('migrations/2026_09_25_000000_align_order_statuses.php');
$migration->up();
check(Order::find($ids[0])->status === 'pending' && Order::find($ids[1])->status === 'confirmed', 'Legacy status conversion failed');
check(Order::orderBy('id')->get(['id', 'total'])->toArray() === $before, 'Upgrade changed order data');
echo "PASS migration over existing legacy orders\n";
echo json_encode(['passed' => true, 'database' => DB::selectOne('SELECT VERSION() AS version')->version, 'scenarios' => 6], JSON_PRETTY_PRINT)."\n";
