<?php
namespace Tests\Feature;

use App\Models\{CartItem, CartReservation, DeliveryOption, Order, ProductVariant, User};
use App\Services\ReservationService;
use Illuminate\Support\Str;
use Tests\TestCase;

class OrderFlowTest extends TestCase
{
    private function customer(): User
    {
        \Illuminate\Support\Facades\Auth::forgetGuards();
        $user = User::factory()->create();
        $this->withHeaders($this->authHeaders($user->createToken('test')->plainTextToken));
        return $user;
    }

    private function prepare(): array
    {
        $variant = ProductVariant::where('is_active', true)->firstOrFail();
        $this->postJson('/api/v1/cart', ['product_variant_id' => $variant->id, 'quantity' => 2])->assertOk();
        $this->postJson('/api/v1/cart/reserve')->assertOk()->assertJsonStructure(['expires_at']);
        $this->postJson('/api/v1/orders/checkout/begin')->assertOk()->assertJsonPath('reservation_extended', true);
        $option = DeliveryOption::active()->firstOrFail();
        $quote = $this->postJson('/api/v1/orders/checkout/quote', ['delivery_option_id' => $option->id, 'city' => 'خانيونس'])
            ->assertOk()->json('data');
        return [
            'delivery_option_id' => $option->id, 'payment_method' => 'cod', 'quote_token' => $quote['quote_token'],
            'address' => ['full_name' => 'عميل اختبار', 'phone' => '+970599123456', 'city' => 'خانيونس', 'area' => 'الأمل', 'details' => 'شارع الاختبار', 'landmark' => 'قرب المدرسة'],
        ];
    }

    public function test_checkout_requires_authentication(): void
    {
        $this->postJson('/api/v1/orders/checkout/begin')->assertUnauthorized();
        $this->postJson('/api/v1/orders', [])->assertUnauthorized();
    }

    public function test_empty_or_unreserved_cart_cannot_begin_checkout(): void
    {
        $this->customer();
        $this->postJson('/api/v1/orders/checkout/begin')->assertStatus(409);
        $v = ProductVariant::first();
        $this->postJson('/api/v1/cart', ['product_variant_id' => $v->id, 'quantity' => 1])->assertOk();
        $this->postJson('/api/v1/orders/checkout/begin')->assertStatus(409);
    }

    public function test_cod_order_consumes_stock_once_and_is_idempotent(): void
    {
        $this->customer();
        $payload = $this->prepare();
        $variant = ProductVariant::first();
        $stock = $variant->stock_quantity;
        $key = (string) Str::uuid();
        $first = $this->withHeader('Idempotency-Key', $key)->postJson('/api/v1/orders', $payload)->assertCreated();
        $number = $first->json('data.order_number');
        $this->assertNoSensitiveData($first->json());
        $this->assertEquals($stock - 2, $variant->fresh()->stock_quantity);
        $this->assertEquals(0, $variant->fresh()->reserved_quantity);
        $this->assertDatabaseCount('orders', 1);
        $this->withHeader('Idempotency-Key', $key)->postJson('/api/v1/orders', $payload)->assertCreated()->assertJsonPath('data.order_number', $number);
        $this->assertDatabaseCount('orders', 1);
        $this->assertDatabaseCount('cart_items', 0);
        $this->getJson('/api/v1/orders')->assertOk()->assertJsonStructure(['data' => [['items', 'subtotal', 'delivery_fee']]]);
        $this->getJson('/api/v1/orders/' . $number)->assertOk()->assertJsonPath('data.address.landmark', 'قرب المدرسة');
        $payload['notes'] = 'different';
        $this->postJson('/api/v1/orders', $payload)->assertStatus(409);
    }

    public function test_price_change_requires_a_new_quote_without_creating_order(): void
    {
        $this->customer(); $payload = $this->prepare();
        ProductVariant::first()->increment('price', 1);
        $this->withHeader('Idempotency-Key', (string) Str::uuid())->postJson('/api/v1/orders', $payload)->assertStatus(409);
        $this->assertDatabaseCount('orders', 0);
        $this->assertDatabaseCount('cart_items', 1);
    }

    public function test_expired_or_removed_reservation_cannot_create_order(): void
    {
        $this->customer(); $payload = $this->prepare();
        $this->travel(31)->minutes();
        $this->withHeader('Idempotency-Key', (string) Str::uuid())->postJson('/api/v1/orders', $payload)->assertStatus(409);
        $this->assertDatabaseCount('orders', 0);
        $service = app(ReservationService::class);
        $this->assertEquals(1, $service->cleanExpired());
        $this->assertEquals(0, $service->cleanExpired());
        $this->assertEquals(0, ProductVariant::first()->reserved_quantity);
        $this->travelBack();
    }

    public function test_heartbeat_is_read_only_and_extension_happens_once(): void
    {
        $this->customer(); $this->prepare();
        $reservation = CartReservation::firstOrFail(); $expiry = $reservation->expires_at->timestamp;
        $this->postJson('/api/v1/cart/heartbeat')->assertOk()->assertJsonPath('is_extended', true);
        $this->postJson('/api/v1/orders/checkout/begin')->assertOk()->assertJsonPath('reservation_extended', false);
        $this->assertEquals($expiry, $reservation->fresh()->expires_at->timestamp);
        $this->travel(31)->minutes();
        $this->postJson('/api/v1/orders/checkout/begin')->assertStatus(409);
        $this->travelBack();
    }

    public function test_quantity_changes_release_reservation_and_enforce_aggregate_limit(): void
    {
        $this->customer(); $this->prepare();
        $item = CartItem::first();
        $this->patchJson('/api/v1/cart/' . $item->id, ['quantity' => 3])->assertOk();
        $this->assertDatabaseCount('cart_reservations', 0);
        $this->assertEquals(0, ProductVariant::first()->reserved_quantity);
        $this->postJson('/api/v1/cart', ['product_variant_id' => $item->product_variant_id, 'quantity' => 8])->assertStatus(409);
        $this->assertEquals(3, $item->fresh()->quantity);
    }

    public function test_other_customer_cannot_read_an_existing_order(): void
    {
        $this->customer(); $payload = $this->prepare();
        $number = $this->withHeader('Idempotency-Key', (string) Str::uuid())->postJson('/api/v1/orders', $payload)->assertCreated()->json('data.order_number');
        $this->customer();
        $this->getJson('/api/v1/orders/' . $number)->assertNotFound();
    }

    public function test_uncovered_city_and_missing_idempotency_key_are_rejected(): void
    {
        $this->customer(); $payload = $this->prepare();
        $this->postJson('/api/v1/orders', $payload)->assertUnprocessable();
        $payload['address']['city'] = 'مدينة غير مخدومة';
        $this->withHeader('Idempotency-Key', (string) Str::uuid())->postJson('/api/v1/orders', $payload)->assertUnprocessable();
        $this->assertDatabaseCount('orders', 0);
    }

    public function test_sandbox_payment_retries_webhooks_and_cod_rejection(): void
    {
        config(['services.jawwal_pay.sandbox' => true]);
        $this->customer(); $payload = $this->prepare(); $payload['payment_method'] = 'jawwal_pay';
        $order = $this->withHeader('Idempotency-Key', (string) Str::uuid())->postJson('/api/v1/orders', $payload)->assertCreated()->json('data');
        $first = $this->postJson('/api/v1/payments/init', ['order_id' => $order['id']])->assertOk()->json();
        $this->postJson('/api/v1/payments/init', ['order_id' => $order['id']])->assertOk()->assertJsonPath('payment_id', $first['payment_id']);
        $this->assertDatabaseCount('payments', 1);
        $webhook = ['merchant_ref' => $order['order_number'], 'transaction_id' => 'test-tx', 'status' => 'SUCCESS', 'amount' => $order['total']];
        $this->postJson('/api/v1/payments/webhook', $webhook)->assertOk();
        $this->postJson('/api/v1/payments/webhook', $webhook)->assertOk();
        $webhook['status'] = 'FAILED';
        $this->postJson('/api/v1/payments/webhook', $webhook)->assertOk();
        $this->assertDatabaseHas('orders', ['id' => $order['id'], 'status' => 'confirmed']);
        $this->assertDatabaseHas('payments', ['order_id' => $order['id'], 'status' => 'completed']);
        $this->assertDatabaseCount('order_tracking', 2);
        config(['services.jawwal_pay.sandbox' => false, 'services.jawwal_pay.webhook_secret' => null]);
        $this->postJson('/api/v1/payments/webhook', $webhook)->assertUnauthorized();
    }
}
