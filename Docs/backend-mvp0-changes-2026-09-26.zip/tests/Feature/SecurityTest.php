<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Redis;
use Tests\TestCase;

/**
 * SecurityTest — اختبارات الأمان المخصصة
 *
 * هذه الاختبارات مكرسة للتحقق من أن البيانات الداخلية
 * (store_id, commission_amount, sub_orders) لا تظهر أبداً
 * في أي response يصله العميل.
 *
 * يجب أن تنجح هذه الاختبارات دائماً — أي فشل هنا يعني ثغرة أمنية.
 */
class SecurityTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        Redis::shouldReceive('setex')->andReturn(true)->byDefault();
        Redis::shouldReceive('get')->andReturn(null)->byDefault();
        Redis::shouldReceive('del')->andReturn(1)->byDefault();
        Redis::shouldReceive('ttl')->andReturn(900)->byDefault();
        Redis::shouldReceive('expire')->andReturn(true)->byDefault();
    }

    // ==========================================
    // الـ Endpoints العامة (Public)
    // ==========================================

    public function test_categories_hides_store_id(): void
    {
        $response = $this->getJson('/api/v1/categories');
        $response->assertStatus(200);

        $json = json_encode($response->json());
        $this->assertStringNotContainsString('"store_id"', $json,
            '🚨 SECURITY: store_id مكشوف في /categories');
    }

    public function test_products_list_hides_store_id(): void
    {
        $response = $this->getJson('/api/v1/products');
        $response->assertStatus(200);

        $json = json_encode($response->json());
        $this->assertStringNotContainsString('"store_id"', $json,
            '🚨 SECURITY: store_id مكشوف في /products');
        $this->assertStringNotContainsString('"commission_amount"', $json,
            '🚨 SECURITY: commission_amount مكشوف في /products');
    }

    public function test_product_detail_hides_store_id(): void
    {
        $response = $this->getJson('/api/v1/products/rose-black');
        $response->assertStatus(200);

        $json = json_encode($response->json());
        $this->assertStringNotContainsString('"store_id"', $json,
            '🚨 SECURITY: store_id مكشوف في تفاصيل المنتج');
        $this->assertStringNotContainsString('"commission_amount"', $json,
            '🚨 SECURITY: commission_amount مكشوف في تفاصيل المنتج');
    }

    public function test_product_variants_hide_internal_data(): void
    {
        $response = $this->getJson('/api/v1/products/rose-black');
        $response->assertStatus(200);

        $variants = $response->json('data.variants') ?? [];

        foreach ($variants as $index => $variant) {
            $variantJson = json_encode($variant);

            $this->assertStringNotContainsString('"store_id"', $variantJson,
                "🚨 SECURITY: store_id مكشوف في variant #{$index}");

            // cost_price لا يجب أن يظهر (سعر الشراء الداخلي)
            $this->assertStringNotContainsString('"cost_price"', $variantJson,
                "🚨 SECURITY: cost_price مكشوف في variant #{$index}");
        }
    }

    // ==========================================
    // الـ Endpoints المحمية (Authenticated)
    // ==========================================

    public function test_orders_list_hides_sub_orders(): void
    {
        $user  = \App\Models\User::factory()->create(['phone' => '0599400500']);
        $token = $user->createToken('sec-test')->plainTextToken;

        $response = $this->withHeaders($this->authHeaders($token))
                         ->getJson('/api/v1/orders');

        if ($response->status() === 200) {
            $json = json_encode($response->json());

            $this->assertStringNotContainsString('"sub_orders"', $json,
                '🚨 SECURITY: sub_orders مكشوف في قائمة الطلبات!');
            $this->assertStringNotContainsString('"commission_amount"', $json,
                '🚨 SECURITY: commission_amount مكشوف في قائمة الطلبات!');
            $this->assertStringNotContainsString('"store_id"', $json,
                '🚨 SECURITY: store_id مكشوف في قائمة الطلبات!');
        }
    }

    // ==========================================
    // Cart Security
    // ==========================================

    public function test_cart_hides_store_id(): void
    {
        $headers  = $this->guestHeaders('security-test-uuid');
        $response = $this->withHeaders($headers)->getJson('/api/v1/cart');

        $response->assertStatus(200);
        $json = json_encode($response->json());

        $this->assertStringNotContainsString('"store_id"', $json,
            '🚨 SECURITY: store_id مكشوف في cart!');
        $this->assertStringNotContainsString('"commission_amount"', $json,
            '🚨 SECURITY: commission_amount مكشوف في cart!');
    }

    // ==========================================
    // Cross-Guest Security (عزل الـ carts)
    // ==========================================

    public function test_cart_isolated_between_guests(): void
    {
        $variantId = \App\Models\ProductVariant::where('is_active', true)->first()->id;
        $owner     = $this->guestHeaders('sec-owner-' . uniqid());
        $stranger  = $this->guestHeaders('sec-stranger-' . uniqid());

        // Owner يضيف عنصراً
        $addRes = $this->withHeaders($owner)->postJson('/api/v1/cart', [
            'product_variant_id' => $variantId,
            'quantity'           => 1,
        ]);

        $addRes->assertOk();

        // Stranger يرى سلة فارغة
        $strangerCart = $this->withHeaders($stranger)->getJson('/api/v1/cart');
        $strangerCart->assertStatus(200);

        $this->assertCount(0, $strangerCart->json('data.items'),
            '🚨 SECURITY: ضيف آخر يرى محتوى سلة ضيف مختلف!');
    }

    // ==========================================
    // Health endpoint (no internal data)
    // ==========================================

    public function test_health_contains_no_internal_data(): void
    {
        $response = $this->getJson('/api/v1/health');
        $response->assertStatus(200);

        $json = json_encode($response->json());
        $this->assertStringNotContainsString('"store_id"', $json);
        $this->assertStringNotContainsString('"commission_amount"', $json);
        $this->assertStringNotContainsString('"password"', $json,
            '🚨 SECURITY: password مكشوف في health endpoint!');
    }

    // ==========================================
    // Delivery options (no store data)
    // ==========================================

    public function test_delivery_options_hides_internal_data(): void
    {
        $response = $this->getJson('/api/v1/delivery-options');



        $response->assertStatus(200);
        $json = json_encode($response->json());

        $this->assertStringNotContainsString('"store_id"', $json,
            '🚨 SECURITY: store_id مكشوف في delivery-options!');
        $this->assertStringNotContainsString('"commission_amount"', $json,
            '🚨 SECURITY: commission_amount مكشوف في delivery-options!');
    }
}
