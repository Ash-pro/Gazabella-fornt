<?php

namespace Tests\Feature;

use App\Models\ProductVariant;
use Illuminate\Support\Facades\Redis;
use Tests\TestCase;

class CartTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        Redis::shouldReceive('setex')->andReturn(true)->byDefault();
        Redis::shouldReceive('get')->andReturn(null)->byDefault();
        Redis::shouldReceive('del')->andReturn(1)->byDefault();
        Redis::shouldReceive('ttl')->andReturn(900)->byDefault();
        Redis::shouldReceive('expire')->andReturn(true)->byDefault();
    }

    private function getFirstVariantId(): int
    {
        return ProductVariant::where('is_active', true)->first()->id;
    }

    // ==========================================
    // Add to Cart
    // ==========================================

    public function test_guest_can_add_item_to_cart(): void
    {
        $variantId = $this->getFirstVariantId();

        $response = $this->withHeaders($this->guestHeaders('add-test-' . uniqid()))
                         ->postJson('/api/v1/cart', [
                             'product_variant_id' => $variantId,
                             'quantity'           => 2,
                         ]);

        $response->assertStatus(200)
                 ->assertJsonStructure([
                     'data' => ['items', 'total_items', 'subtotal'],
                 ]);

        // تحقق أن العنصر أُضيف بالفعل
        $this->assertNotEmpty($response->json('data.items'));
        $this->assertEquals(2, $response->json('data.items.0.quantity'));
    }

    public function test_add_to_cart_validates_required_fields(): void
    {
        $response = $this->withHeaders($this->guestHeaders())
                         ->postJson('/api/v1/cart', []);

        $response->assertStatus(422)
                 ->assertJsonValidationErrors(['product_variant_id', 'quantity']);
    }

    public function test_add_to_cart_validates_quantity_min_1(): void
    {
        $variantId = $this->getFirstVariantId();

        $response = $this->withHeaders($this->guestHeaders())
                         ->postJson('/api/v1/cart', [
                             'product_variant_id' => $variantId,
                             'quantity'           => 0,
                         ]);

        $response->assertStatus(422)
                 ->assertJsonValidationErrors(['quantity']);
    }

    public function test_add_to_cart_rejects_inactive_variant(): void
    {
        $inactive = ProductVariant::firstOrFail();
        $inactive->update(['is_active' => false]);

        $response = $this->withHeaders($this->guestHeaders())
                         ->postJson('/api/v1/cart', [
                             'product_variant_id' => $inactive->id,
                             'quantity'           => 1,
                         ]);

        $response->assertStatus(404);
    }

    // ==========================================
    // Get Cart
    // ==========================================

    public function test_guest_can_get_empty_cart(): void
    {
        $response = $this->withHeaders($this->guestHeaders('empty-cart-' . uniqid()))
                         ->getJson('/api/v1/cart');

        $response->assertStatus(200)
                 ->assertJsonStructure([
                     'data' => ['items', 'subtotal', 'total_items'],
                 ]);

        $this->assertCount(0, $response->json('data.items'));
    }

    public function test_cart_returns_items_after_adding(): void
    {
        $variantId = $this->getFirstVariantId();
        $headers   = $this->guestHeaders('cart-test-' . uniqid());

        // Add item
        $this->withHeaders($headers)->postJson('/api/v1/cart', [
            'product_variant_id' => $variantId,
            'quantity'           => 3,
        ]);

        // Get cart
        $response = $this->withHeaders($headers)->getJson('/api/v1/cart');

        $response->assertStatus(200);
        $items = $response->json('data.items');
        $this->assertCount(1, $items);
        $this->assertEquals(3, $items[0]['quantity']);
    }

    // ==========================================
    // Update Cart
    // ==========================================

    public function test_guest_can_update_cart_item_quantity(): void
    {
        $variantId = $this->getFirstVariantId();
        $headers   = $this->guestHeaders('update-cart-' . uniqid());

        // Add item — returns full cart
        $addResponse = $this->withHeaders($headers)->postJson('/api/v1/cart', [
            'product_variant_id' => $variantId,
            'quantity'           => 1,
        ]);

        $addResponse->assertStatus(200);
        $cartItemId = $addResponse->json('data.items.0.id');

        // Update via PATCH
        $response = $this->withHeaders($headers)
                         ->patchJson("/api/v1/cart/{$cartItemId}", ['quantity' => 5]);

        $response->assertStatus(200);
        // Response هو الـ full cart
        $updatedItem = collect($response->json('data.items'))
            ->firstWhere('id', $cartItemId);

        $this->assertEquals(5, $updatedItem['quantity']);
    }

    // ==========================================
    // Delete Cart Item
    // ==========================================

    public function test_guest_can_remove_cart_item(): void
    {
        $variantId = $this->getFirstVariantId();
        $headers   = $this->guestHeaders('delete-cart-' . uniqid());

        // Add item
        $addResponse = $this->withHeaders($headers)->postJson('/api/v1/cart', [
            'product_variant_id' => $variantId,
            'quantity'           => 1,
        ]);

        $addResponse->assertStatus(200);
        $cartItemId = $addResponse->json('data.items.0.id');

        // Delete
        $deleteResponse = $this->withHeaders($headers)
                               ->deleteJson("/api/v1/cart/{$cartItemId}");

        $deleteResponse->assertStatus(200);

        // Cart should be empty now
        $cart = $this->withHeaders($headers)->getJson('/api/v1/cart');
        $this->assertCount(0, $cart->json('data.items'));
    }

    public function test_guest_cannot_delete_other_guests_cart_item(): void
    {
        $variantId = $this->getFirstVariantId();
        $owner     = $this->guestHeaders('owner-uuid-' . uniqid());
        $attacker  = $this->guestHeaders('attacker-uuid-' . uniqid());

        // Owner adds item
        $addResponse = $this->withHeaders($owner)->postJson('/api/v1/cart', [
            'product_variant_id' => $variantId,
            'quantity'           => 1,
        ]);

        $addResponse->assertStatus(200);
        $cartItemId = $addResponse->json('data.items.0.id');

        // Attacker tries to delete
        $response = $this->withHeaders($attacker)
                         ->deleteJson("/api/v1/cart/{$cartItemId}");

        $response->assertStatus(404); // Not found for this guest
    }

    // ==========================================
    // Heartbeat (READ-ONLY)
    // ==========================================

    public function test_heartbeat_returns_200_and_is_read_only(): void
    {
        $response = $this->withHeaders($this->guestHeaders('heartbeat-' . uniqid()))
                         ->postJson('/api/v1/cart/heartbeat');

        // Heartbeat = READ ONLY — لا يمدد الحجز أبداً
        $response->assertStatus(200)
                 ->assertJsonStructure([
                     'has_reservation',
                     'seconds_remaining',
                     'is_extended',
                     'expires_at',
                 ]);

        // لا يوجد حجز نشط → has_reservation = false
        $this->assertFalse($response->json('has_reservation'));
        $this->assertNull($response->json('seconds_remaining'));
        $this->assertFalse($response->json('is_extended'));
        $this->assertNull($response->json('expires_at'));
    }
}
