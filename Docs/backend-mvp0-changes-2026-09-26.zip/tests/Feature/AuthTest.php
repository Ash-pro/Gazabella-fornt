<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Support\Facades\Redis;
use Tests\TestCase;

class AuthTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        $this->assertTrue(config('gazabella.otp.test_mode'));
        $this->assertSame('123456', config('gazabella.otp.test_code'));
        \Illuminate\Support\Facades\Http::preventStrayRequests();
        Redis::shouldReceive('setex')->never();
        Redis::shouldReceive('get')->never();
        Redis::shouldReceive('del')->never();
        Redis::shouldReceive('ttl')->never();
    }

    // ==========================================
    // Send OTP
    // ==========================================

    public function test_send_otp_returns_200_for_valid_phone(): void
    {
        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/send', [
                             'phone' => '+970599123456',
                         ]);

        $response->assertStatus(200)
                 ->assertJsonStructure(['message']);
    }

    public function test_send_otp_validates_phone_required(): void
    {
        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/send', []);

        $response->assertStatus(422)
                 ->assertJsonValidationErrors(['phone']);
    }

    public function test_send_otp_validates_phone_format(): void
    {
        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/send', [
                             'phone' => 'not-a-phone',
                         ]);

        $response->assertStatus(422)
                 ->assertJsonValidationErrors(['phone']);
    }

    // ==========================================
    // Verify OTP
    // ==========================================

    public function test_verify_otp_returns_token_for_valid_code(): void
    {
        $phone = '+970599111222';
        $otp   = '123456';


        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/verify', [
                             'phone' => $phone,
                             'otp'   => $otp,
                         ]);

        $response->assertStatus(200)
                 ->assertJsonStructure(['token', 'token_type', 'user']);

        $this->assertNotEmpty($response->json('token'));
    }

    public function test_verify_otp_fails_for_wrong_code(): void
    {
        $phone = '+970599333444';


        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/verify', [
                             'phone' => $phone,
                             'otp'   => '000000',
                         ]);

        $response->assertStatus(401);
    }

    public function test_test_mode_send_returns_fixed_code_without_external_services(): void
    {
        $service = app(\App\Services\OtpService::class);
        $this->assertSame('123456', $service->send('+970599555666'));
        $this->assertTrue($service->verify('+970599555666', '123456'));
        $this->assertFalse($service->verify('+970599555666', '000000'));
        \Illuminate\Support\Facades\Http::assertNothingSent();
    }

    public function test_verify_otp_validates_required_fields(): void
    {
        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/verify', []);

        $response->assertStatus(422)
                 ->assertJsonValidationErrors(['phone', 'otp']);
    }

    public function test_verify_otp_validates_otp_is_6_digits(): void
    {
        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/verify', [
                             'phone' => '+970599123456',
                             'otp'   => '123',
                         ]);

        $response->assertStatus(422)
                 ->assertJsonValidationErrors(['otp']);
    }

    // ==========================================
    // Security
    // ==========================================

    public function test_verified_user_response_has_no_sensitive_data(): void
    {
        $phone = '+970599777888';
        $otp   = '123456';


        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->postJson('/api/v1/auth/otp/verify', [
                             'phone' => $phone,
                             'otp'   => $otp,
                         ]);

        $response->assertOk();
        $this->assertNoSensitiveData($response->json());

        $json = json_encode($response->json());
        $this->assertStringNotContainsString('"password"', $json,
            '🚨 password مكشوف في response المستخدم!');
    }

    // ==========================================
    // Authenticated user profile
    // ==========================================

    public function test_authenticated_user_can_get_profile(): void
    {
        $user  = User::factory()->create(['phone' => '+970599000111']);
        $token = $user->createToken('test-token')->plainTextToken;

        $response = $this->withHeaders($this->authHeaders($token))
                         ->getJson('/api/v1/auth/me');



        $response->assertStatus(200)
                 ->assertJsonStructure(['data' => ['phone']]);
    }

    public function test_unauthenticated_request_to_protected_endpoint(): void
    {
        $response = $this->withHeaders(['Accept' => 'application/json'])
                         ->getJson('/api/v1/auth/me');

        $response->assertStatus(401);
    }
}
