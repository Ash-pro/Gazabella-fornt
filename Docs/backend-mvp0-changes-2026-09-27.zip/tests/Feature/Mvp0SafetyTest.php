<?php
namespace Tests\Feature;

use App\Models\{CartItem, CartReservation, Coupon, GuestSession, ProductVariant, User};
use App\Services\{CartService, ReservationService};
use Illuminate\Support\Str;
use Tests\TestCase;

class Mvp0SafetyTest extends TestCase
{
    public function test_catalog_exposes_only_valid_same_variant_previous_prices(): void
    {
        $v = ProductVariant::firstOrFail();
        $v->update(['price' => 45, 'compare_at_price' => 60]);
        $this->getJson('/api/v1/products/'.$v->product->slug)->assertOk()
            ->assertJsonFragment(['id' => $v->id, 'price' => 45, 'compare_at_price' => 60]);
        foreach ([null, 40, 45] as $original) {
            $v->update(['compare_at_price' => $original]);
            $this->getJson('/api/v1/products/'.$v->product->slug)->assertOk()
                ->assertJsonFragment(['id' => $v->id, 'price' => 45, 'compare_at_price' => null]);
        }
    }

    public function test_catalog_price_range_matches_the_displayed_starting_price(): void
    {
        $v = ProductVariant::firstOrFail();
        $v->product->variants()->update(['price' => 75]);
        $v->refresh()->update(['price' => 45, 'is_active' => true]);
        $this->getJson('/api/v1/products?min_price=60&max_price=80')
            ->assertOk()->assertJsonMissing(['id' => $v->product_id, 'slug' => $v->product->slug]);
        $this->getJson('/api/v1/products?min_price=40&max_price=50')
            ->assertOk()->assertJsonFragment(['slug' => $v->product->slug, 'min_price' => 45]);
    }

    public function test_last_unit_cannot_be_reserved_by_two_customers(): void
    {
        $v = ProductVariant::firstOrFail();
        $v->update(['stock_quantity' => 1, 'reserved_quantity' => 0]);
        $cart = app(CartService::class);
        $a = $cart->addItem(User::factory()->create(), $v->id, 1);
        $b = $cart->addItem(User::factory()->create(), $v->id, 1);
        app(ReservationService::class)->reserve($a);
        try {
            app(ReservationService::class)->reserve($b);
            $this->fail('The same unit was reserved twice.');
        } catch (\DomainException) {
            $this->assertEquals(1, $v->fresh()->reserved_quantity);
            $this->assertDatabaseCount('cart_reservations', 1);
        }
    }

    public function test_repeated_reserve_and_expired_replacement_do_not_double_count_stock(): void
    {
        $v = ProductVariant::firstOrFail();
        $item = app(CartService::class)->addItem(User::factory()->create(), $v->id, 2);
        $service = app(ReservationService::class);
        $first = $service->reserve($item);
        $this->assertEquals($first->id, $service->reserve($item)->id);
        $this->travel(16)->minutes();
        $next = $service->reserve($item);
        $service->release($first); // A late cleanup must not release the replacement reservation.
        $this->assertEquals(2, $v->fresh()->reserved_quantity);
        $this->assertDatabaseCount('cart_reservations', 1);
        $this->assertNotEquals($first->id, $next->id);
        $this->travelBack();
    }

    public function test_otp_merges_duplicate_variants_without_losing_quantity_or_reservations(): void
    {
        config(['gazabella.otp.test_mode' => true, 'gazabella.otp.test_code' => '123456']);
        $user = User::factory()->create(['phone' => '+970599321456']);
        $guest = GuestSession::create(['uuid' => (string) Str::uuid(), 'expires_at' => now()->addHour()]);
        $v = ProductVariant::firstOrFail();
        $cart = app(CartService::class);
        $a = $cart->addItem($user, $v->id, 2);
        $b = $cart->addItem($guest, $v->id, 3);
        app(ReservationService::class)->reserve($a);
        app(ReservationService::class)->reserve($b);
        $this->withHeader('X-Guest-UUID', $guest->uuid)->postJson('/api/v1/auth/otp/verify', ['phone' => $user->phone, 'otp' => '123456'])
            ->assertOk()->assertJsonPath('cart_merged', true);
        $this->assertDatabaseCount('cart_items', 1);
        $this->assertEquals(5, CartItem::where('user_id', $user->id)->firstOrFail()->quantity);
        $this->assertEquals(0, $v->fresh()->reserved_quantity);
        $this->assertDatabaseCount('cart_reservations', 0);
    }

    public function test_invalid_coupon_is_rejected_in_checkout_summary(): void
    {
        $user = User::factory()->create();
        $item = app(CartService::class)->addItem($user, ProductVariant::first()->id, 1);
        app(ReservationService::class)->reserve($item);
        Coupon::create(['code' => 'EXPIRED', 'type' => 'fixed', 'value' => 5, 'is_active' => true, 'expires_at' => now()->subDay()]);
        $this->withHeaders($this->authHeaders($user->createToken('test')->plainTextToken))
            ->postJson('/api/v1/orders/checkout/begin', ['coupon_code' => 'EXPIRED'])->assertUnprocessable();
    }
}
