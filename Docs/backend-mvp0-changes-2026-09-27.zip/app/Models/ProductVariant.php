<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * مصدر الحقيقة للمخزون
 * available_quantity = stock_quantity - reserved_quantity
 */
class ProductVariant extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_id', 'name', 'attributes', 'price', 'compare_at_price',
        'stock_quantity', 'reserved_quantity', 'sku', 'is_active',
    ];

    protected $casts = [
        'attributes' => 'array',
        'price' => 'decimal:2',
        'compare_at_price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function cartItems()
    {
        return $this->hasMany(CartItem::class);
    }

    public function reservations()
    {
        return $this->hasMany(CartReservation::class)->where('expires_at', '>', now());
    }

    /**
     * الكمية المتاحة الفعلية
     */
    public function getAvailableQuantityAttribute(): int
    {
        return max(0, $this->stock_quantity - $this->reserved_quantity);
    }

    public function isAvailable(int $qty = 1): bool
    {
        return $this->is_active && $this->available_quantity >= $qty;
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
