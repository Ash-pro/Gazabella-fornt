<?php

namespace App\Filament\Resources\ProductResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class VariantsRelationManager extends RelationManager
{
    protected static string $relationship   = 'variants';
    protected static ?string $title         = 'المتغيرات (Variants)';
    protected static ?string $modelLabel    = 'متغير';

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('name')
                ->label('اسم المتغير')
                ->required()
                ->maxLength(100)
                ->placeholder('مثال: 50ml، أحمر كلاسيكي'),

            Forms\Components\TextInput::make('sku')
                ->label('SKU')
                ->required()
                ->unique(ignoreRecord: true)
                ->maxLength(100),

            Forms\Components\TextInput::make('price')
                ->label('سعر البيع الحالي (₪)')
                ->numeric()
                ->required()
                ->prefix('₪'),

            Forms\Components\TextInput::make('compare_at_price')
                ->label('السعر السابق قبل الخصم (₪)')
                ->numeric()
                ->nullable()
                ->gt('price')
                ->helperText('اختياري؛ يجب أن يكون أعلى من سعر البيع الحالي. اتركه فارغًا إذا لم يوجد خصم.')
                ->prefix('₪'),

            Forms\Components\TextInput::make('stock_quantity')
                ->label('الكمية في المخزون')
                ->numeric()
                ->required()
                ->minValue(0)
                ->default(0),

            Forms\Components\TextInput::make('reserved_quantity')
                ->label('المحجوز')
                ->numeric()
                ->default(0)
                ->disabled()
                ->dehydrated(false),

            Forms\Components\KeyValue::make('attributes')
                ->label('الخصائص')
                ->keyLabel('المفتاح')
                ->valueLabel('القيمة')
                ->nullable()
                ->columnSpanFull(),

            Forms\Components\Toggle::make('is_active')
                ->label('نشط')
                ->default(true),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('الاسم')
                    ->searchable(),

                Tables\Columns\TextColumn::make('sku')
                    ->label('SKU')
                    ->copyable(),

                Tables\Columns\TextColumn::make('price')
                    ->label('السعر')
                    ->money('ILS'),

                Tables\Columns\TextColumn::make('stock_quantity')
                    ->label('المخزون')
                    ->badge()
                    ->color(fn (int $state) => $state <= 5 ? 'danger' : ($state <= 20 ? 'warning' : 'success')),

                Tables\Columns\TextColumn::make('reserved_quantity')
                    ->label('محجوز')
                    ->badge()
                    ->color('info'),

                Tables\Columns\IconColumn::make('is_active')
                    ->label('نشط')
                    ->boolean(),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()->label('إضافة متغير'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
