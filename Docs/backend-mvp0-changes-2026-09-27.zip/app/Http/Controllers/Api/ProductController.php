<?php

namespace App\Http\Controllers\Api;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends BaseApiController
{
    /**
     * GET /api/v1/categories
     * فئات الجذر مع الفئات الفرعية
     */
    public function categories(): JsonResponse
    {
        $categories = Category::active()
            ->whereNull('parent_id')
            ->with(['children' => fn($q) => $q->active()])
            ->get()
            ->map(fn($cat) => [
                'id'          => $cat->id,
                'name'        => $cat->name,
                'slug'        => $cat->slug,
                'image_url'   => $cat->image,
                'sort_order'  => $cat->sort_order,
                'subcategories' => $cat->children->map(fn($sub) => [
                    'id'         => $sub->id,
                    'name'       => $sub->name,
                    'slug'       => $sub->slug,
                    'image_url'  => $sub->image,
                    'sort_order' => $sub->sort_order,
                ]),
            ]);

        return response()->json([
            'data' => $categories,
        ]);
    }

    /**
     * GET /api/v1/products
     * قائمة المنتجات مع فلترة وصفحات
     */
    public function index(Request $request): JsonResponse
    {
        $query = Product::active()
            ->with(['category', 'variants' => fn($q) => $q->active(), 'primaryImage']);

        $query->withMin(['variants as catalog_price' => fn ($q) => $q->active()], 'price');
        if ($categoryId = $request->integer('category_id')) {
            $ids = Category::where('id', $categoryId)->orWhere('parent_id', $categoryId)->pluck('id');
            $query->whereIn('category_id', $ids);
        }
        $request->validate(['min_price' => 'nullable|numeric|min:0', 'max_price' => 'nullable|numeric|min:0']);
        // Filter the same starting price displayed on product cards.
        $catalogPrice = 'CAST((SELECT MIN(price) FROM product_variants WHERE product_id = products.id AND is_active = 1) AS DECIMAL(12,2))';
        if ($request->filled('min_price')) $query->whereRaw($catalogPrice.' >= ?', [$request->query('min_price')]);
        if ($request->filled('max_price')) $query->whereRaw($catalogPrice.' <= ?', [$request->query('max_price')]);
        // فلترة حسب الفئة
        if ($categorySlug = $request->query('category')) {
            $category = Category::where('slug', $categorySlug)->first();
            $ids = $category ? Category::where('id', $category->id)->orWhere('parent_id', $category->id)->pluck('id') : [];
            $query->whereIn('category_id', $ids);
        }

        // بحث بالاسم
        if ($search = $request->query('search')) {
            $query->where('name', 'like', "%{$search}%");
        }

        // فرز
        $sort = $request->query('sort', 'newest');
        match ($sort) {
            'price_asc'  => $query->orderBy('catalog_price', 'asc'),
            'price_desc' => $query->orderBy('catalog_price', 'desc'),
            'popular'    => $query->orderBy('id', 'asc'), // TODO: sales_count
            default      => $query->latest(),             // newest
        };

        $paginator = $query->paginate(max(1, min(100, (int) $request->query('per_page', 20))));

        $items = collect($paginator->items())->map(fn($product) => $this->formatProduct($product));

        return response()->json([
            'data' => $items,
            'meta' => [
                'current_page' => $paginator->currentPage(),
                'per_page'     => $paginator->perPage(),
                'total'        => $paginator->total(),
                'last_page'    => $paginator->lastPage(),
            ],
        ]);
    }

    /**
     * GET /api/v1/products/{slug}
     * تفاصيل منتج واحد
     */
    public function show(string $slug): JsonResponse
    {
        $product = Product::active()
            ->where('slug', $slug)
            ->with(['category', 'variants' => fn($q) => $q->active(), 'images'])
            ->firstOrFail();

        return response()->json([
            'data' => $this->formatProduct($product, detailed: true),
        ]);
    }

    // ──────────────────────────────────────────────
    // Internal formatters (store_id مخفي عبر $hidden)
    // ──────────────────────────────────────────────

    private function formatProduct(Product $product, bool $detailed = false): array
    {
        $primaryImage = $product->primaryImage ?? $product->images?->first();
        $cheapestVariant = $product->variants->sortBy('price')->first();

        $base = [
            'id'           => $product->id,
            'name'         => $product->name,
            'slug'         => $product->slug,
            'base_price'   => (float) $product->base_price,
            'min_price'    => $cheapestVariant ? (float) $cheapestVariant->price : (float) $product->base_price,
            'thumbnail_url'=> $primaryImage?->url,
            'category'     => [
                'id'   => $product->category->id,
                'name' => $product->category->name,
                'slug' => $product->category->slug,
            ],
            'variants'     => $product->variants->map(fn($v) => [
                'id'                 => $v->id,
                'name'               => $v->name,
                'attributes'         => $v->attributes,
                'price'              => (float) $v->price,
                'compare_at_price'   => $v->compare_at_price !== null && $v->compare_at_price > $v->price ? (float) $v->compare_at_price : null,
                'available_quantity' => $v->available_quantity,
                'sku'                => $v->sku,
            ]),
        ];

        if ($detailed) {
            $base['description'] = $product->description;
            $base['images']      = $product->images->map(fn($img) => [
                'id'         => $img->id,
                'url'        => $img->url,
                'is_primary' => (bool) $img->is_primary,
            ]);
        }

        return $base;
    }
}
