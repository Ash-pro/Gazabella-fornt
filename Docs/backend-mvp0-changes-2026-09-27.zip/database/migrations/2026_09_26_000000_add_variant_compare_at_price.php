<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('product_variants', fn (Blueprint $table) => $table->decimal('compare_at_price', 10, 2)->nullable());
    }
    public function down(): void {
        Schema::table('product_variants', fn (Blueprint $table) => $table->dropColumn('compare_at_price'));
    }
};
